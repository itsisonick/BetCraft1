import { User, Book } from '../App';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { ScrollArea } from './ui/scroll-area';
import { Separator } from './ui/separator';
import { ArrowLeft, Coins, Users, TrendingUp, TrendingDown } from 'lucide-react';

interface ProfileScreenProps {
  user: User;
  books: Book[];
  onNavigateBack: () => void;
}

export default function ProfileScreen({ user, books, onNavigateBack }: ProfileScreenProps) {
  const userBooks = books.filter((book) => user.booksJoined.includes(book.id));
  const wins = user.pastBets.filter((bet) => bet.result === 'win').length;
  const losses = user.pastBets.filter((bet) => bet.result === 'loss').length;
  const winRate = user.pastBets.length > 0 ? (wins / user.pastBets.length) * 100 : 0;

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-blue-900 via-blue-800 to-blue-950 text-white">
      {/* Header */}
      <div className="p-6 pb-8 bg-gradient-to-r from-blue-600 to-purple-600">
        <div className="flex items-center justify-between mb-6">
          <Button
            variant="ghost"
            size="icon"
            onClick={onNavigateBack}
            className="text-white hover:bg-white/20"
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </div>

        {/* Profile Info */}
        <div className="flex flex-col items-center text-center mb-6">
          <Avatar className="h-24 w-24 border-4 border-white mb-4">
            <AvatarImage src={user.avatar} />
            <AvatarFallback>{user.username[0]}</AvatarFallback>
          </Avatar>
          <h1 className="text-2xl mb-2">{user.username}</h1>
          <Badge className="mb-3 bg-white/20 text-white border-white/30 capitalize">
            {user.role}
          </Badge>
          
          {/* Chip Info Notice */}
          <div className="bg-white/10 border border-white/20 rounded-lg p-3 max-w-xs mx-auto">
            <p className="text-xs text-blue-100">
              💡 Chip balances are specific to each book you've joined.
            </p>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-3">
          <Card className="p-4 bg-white/10 border-white/20 backdrop-blur-sm text-center">
            <div className="text-2xl mb-1">{userBooks.length}</div>
            <div className="text-xs text-blue-200 opacity-80">Books</div>
          </Card>
          <Card className="p-4 bg-white/10 border-white/20 backdrop-blur-sm text-center">
            <div className="text-2xl mb-1">{wins}</div>
            <div className="text-xs text-blue-200 opacity-80">Wins</div>
          </Card>
          <Card className="p-4 bg-white/10 border-white/20 backdrop-blur-sm text-center">
            <div className="text-2xl mb-1">{winRate.toFixed(0)}%</div>
            <div className="text-xs text-blue-200 opacity-80">Win Rate</div>
          </Card>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 p-6 space-y-6">
        {/* Books Joined */}
        <div>
          <h2 className="text-xl mb-3">My Books</h2>
          <div className="space-y-2">
            {userBooks.map((book) => (
              <Card
                key={book.id}
                className="p-4 bg-gradient-to-br from-blue-700/40 to-purple-700/40 border-blue-500/30 backdrop-blur-sm"
              >
                <div className="flex items-center gap-3">
                  <div className="text-3xl">{book.logo}</div>
                  <div className="flex-1">
                    <div className="text-white">{book.name}</div>
                    <div className="text-sm text-blue-200 opacity-80 flex items-center gap-1">
                      <Users className="h-3 w-3" />
                      {book.members} members
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>

        <Separator className="bg-white/20" />

        {/* Bet History */}
        <div>
          <h2 className="text-xl mb-3">Bet History</h2>
          <ScrollArea className="h-80">
            <div className="space-y-3 pr-4">
              {user.pastBets.map((bet) => (
                <Card
                  key={bet.id}
                  className="p-4 bg-gradient-to-br from-blue-700/40 to-purple-700/40 border-blue-500/30 backdrop-blur-sm"
                >
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex-1">
                      <div className="text-white mb-1">{bet.title}</div>
                      <div className="flex items-center gap-2">
                        {bet.result === 'win' ? (
                          <Badge className="bg-green-500/20 text-green-300 border-green-500/30">
                            <TrendingUp className="h-3 w-3 mr-1" />
                            Won
                          </Badge>
                        ) : (
                          <Badge className="bg-red-500/20 text-red-300 border-red-500/30">
                            <TrendingDown className="h-3 w-3 mr-1" />
                            Lost
                          </Badge>
                        )}
                        <span
                          className={`text-sm flex items-center gap-1 ${
                            bet.result === 'win' ? 'text-green-400' : 'text-red-400'
                          }`}
                        >
                          {bet.result === 'win' ? '+' : ''}
                          {bet.chips} chips
                        </span>
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </ScrollArea>
        </div>
      </div>
    </div>
  );
}
