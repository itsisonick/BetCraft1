# BetCraft Setup Instructions

## Prerequisites
- Node.js 18+ installed
- pnpm package manager (`npm install -g pnpm`)

## Installation Steps

1. Extract/clone this project
2. Navigate to the project directory
3. Install dependencies:
   ```bash
   pnpm install
   ```

4. Start the development server:
   ```bash
   pnpm dev
   ```

5. Open your browser to the localhost URL shown in the terminal

## Project Overview
BetCraft is a social prediction betting app using virtual chips with a ClubGG-style dual chip system (blue distributor chips and red playable chips).

## Features
- Create and join prediction books
- Place bets on various outcomes
- House edge system (3-10%)
- Book Mode vs Prediction Market Mode
- Real-time chip management
- Analytics dashboard
