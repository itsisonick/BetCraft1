import { useState } from 'react';
import { Toaster } from './components/ui/sonner';
import { toast } from 'sonner';
import { Button } from './components/ui/button';
import HomeScreen from './components/HomeScreen';
import ClubPage from './components/ClubPage';
import CreateBetScreen from './components/CreateBetScreen';
import BetDetailsScreen from './components/BetDetailsScreen';
import ProfileScreen from './components/ProfileScreen';
import CreateBookScreen from './components/CreateBookScreen';
import BookSettingsScreen, { BookSettings } from './components/BookSettingsScreen';
import { ClubDataScreen } from './components/ClubDataScreen';

export type Screen = 'home' | 'book' | 'create-bet' | 'bet-details' | 'profile' | 'bets' | 'activity' | 'create-book' | 'book-settings' | 'club-data';

export interface Book {
  id: number;
  bookId: string;
  name: string;
  logo: string;
  members: number;
  activeBets: number;
  ownerId: number;
  ownerName: string;
  totalRedChips: number;
  totalBlueChips: number;
  defaultHouseEdge: number; // Default house edge for new bets (3-10%)
}

export interface BetOutcome {
  id: string;
  name: string;
  odds: number;
  users: number;
  totalChips: number;
}

export interface Bet {
  id: number;
  bookId: number;
  title: string;
  description: string;
  type: 'Sports' | 'IRL' | 'Funny' | 'Custom';
  outcomes: BetOutcome[];
  minBet: number;
  maxBet: number;
  houseEdge: number; // Percentage (e.g., 7 = 7%)
  autoRebalance: boolean;
  status: 'active' | 'completed';
  winningOutcomeId?: string;
  
  // Legacy fields for backward compatibility
  sideA?: string;
  sideB?: string;
  oddsA?: number;
  oddsB?: number;
  chipAmount?: number;
  usersOnA?: number;
  usersOnB?: number;
  chipsOnA?: number;
  chipsOnB?: number;
}

export interface User {
  id: number;
  username: string;
  avatar: string;
  // NOTE: In production, chips should be stored per-club using UserClubBalance interface
  // Current implementation uses global values for simplicity
  redChips: number; // Playable chips - for betting (should be per-club)
  blueChips: number; // Distributor chips - for agents/owners to distribute (should be per-club)
  role: 'owner' | 'agent' | 'player'; // Global role (should be per-club)
  booksJoined: number[];
  pastBets: {
    id: number;
    title: string;
    result: 'win' | 'loss';
    chips: number;
  }[];
}

export interface Player {
  id: number;
  username: string;
  avatar: string;
  redChips: number;
  bookId: number;
}

export interface UserRole {
  bookId: number;
  role: 'Manager' | 'Agent' | 'Player';
}

// Club-specific chip balance (future implementation)
// This interface defines how chips should be stored per-club
export interface UserClubBalance {
  userId: number;
  clubId: number;
  redChips: number; // Playable chips for this specific club
  blueChips: number; // Distributor chips for this specific club (owner/agent only)
  role: 'owner' | 'agent' | 'player'; // User's role in this specific club
}

// Mock data
export const mockUser: User = {
  id: 1,
  username: 'Stevewilldoit',
  avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=IsoNick1',
  redChips: 0, // Playable chips (owners don't have red chips)
  blueChips: 999999, // Distributor chips (unlimited for owners)
  role: 'owner',
  booksJoined: [1, 2, 3],
  pastBets: [
    { id: 1, title: 'Lakers vs Warriors', result: 'win', chips: 500 },
    { id: 2, title: 'Next President', result: 'win', chips: 1000 },
    { id: 3, title: 'Super Bowl Winner', result: 'loss', chips: -300 },
    { id: 4, title: 'Oscar Best Picture', result: 'win', chips: 750 },
    { id: 5, title: 'Tesla Stock Prediction', result: 'loss', chips: -200 },
  ],
};

export const mockBooks: Book[] = [
  { id: 1, bookId: 'SF2847', name: 'Sports Fanatics', logo: '🏀', members: 47, activeBets: 8, ownerId: 1, ownerName: 'Stevewilldoit', totalRedChips: 36840, totalBlueChips: 125000, defaultHouseEdge: 7 },
  { id: 2, bookId: 'MB1923', name: 'Movie Buffs', logo: '🎬', members: 32, activeBets: 3, ownerId: 2, ownerName: 'FilmFan42', totalRedChips: 24500, totalBlueChips: 85000, defaultHouseEdge: 7 },
  { id: 3, bookId: 'TP4561', name: 'Tech Predictions', logo: '💻', members: 56, activeBets: 12, ownerId: 1, ownerName: 'Stevewilldoit', totalRedChips: 52300, totalBlueChips: 180000, defaultHouseEdge: 7 },
];

// User roles in each book
export const mockUserRoles: UserRole[] = [
  { bookId: 1, role: 'Manager' },
  { bookId: 2, role: 'Agent' },
  { bookId: 3, role: 'Manager' },
];

// Mock players for each book
export const mockPlayers: Player[] = [
  // Sports Fanatics (Book 1)
  { id: 1, username: 'Stevewilldoit', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=IsoNick1', redChips: 15420, bookId: 1 },
  { id: 2, username: 'BetKing88', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=BetKing88', redChips: 8300, bookId: 1 },
  { id: 3, username: 'LuckyChip', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=LuckyChip', redChips: 6750, bookId: 1 },
  { id: 4, username: 'SportsFan23', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=SportsFan23', redChips: 4200, bookId: 1 },
  { id: 5, username: 'GoldenBet', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=GoldenBet', redChips: 2170, bookId: 1 },
  
  // Movie Buffs (Book 2)
  { id: 6, username: 'FilmFan42', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=FilmFan42', redChips: 12500, bookId: 2 },
  { id: 7, username: 'Stevewilldoit', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=IsoNick1', redChips: 7800, bookId: 2 },
  { id: 8, username: 'MovieBuff99', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=MovieBuff99', redChips: 4200, bookId: 2 },
  
  // Tech Predictions (Book 3)
  { id: 9, username: 'Stevewilldoit', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=IsoNick1', redChips: 18900, bookId: 3 },
  { id: 10, username: 'TechGuru', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=TechGuru', redChips: 11400, bookId: 3 },
  { id: 11, username: 'CodeMaster', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=CodeMaster', redChips: 9500, bookId: 3 },
  { id: 12, username: 'AIFanatic', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=AIFanatic', redChips: 6300, bookId: 3 },
  { id: 13, username: 'CryptoKing', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=CryptoKing', redChips: 6200, bookId: 3 },
];

export const mockBets: Bet[] = [
  {
    id: 1,
    bookId: 1,
    title: 'Lakers vs Warriors - Who wins?',
    description: 'Thursday night showdown at Staples Center',
    type: 'Sports',
    outcomes: [
      { id: '1', name: 'Lakers', odds: 1.8, users: 12, totalChips: 1200 },
      { id: '2', name: 'Warriors', odds: 2.2, users: 8, totalChips: 800 },
    ],
    minBet: 50,
    maxBet: 1000,
    houseEdge: 7,
    autoRebalance: true,
    status: 'active',
    // Legacy fields for compatibility
    sideA: 'Lakers',
    sideB: 'Warriors',
    oddsA: 1.8,
    oddsB: 2.2,
    chipAmount: 100,
    usersOnA: 12,
    usersOnB: 8,
    chipsOnA: 1200,
    chipsOnB: 800,
  },
  {
    id: 2,
    bookId: 1,
    title: 'Next NBA MVP',
    description: 'Who will win the 2025-2026 MVP award?',
    type: 'Sports',
    outcomes: [
      { id: '1', name: 'Giannis', odds: 2.0, users: 15, totalChips: 3000 },
      { id: '2', name: 'Jokic', odds: 2.0, users: 14, totalChips: 2800 },
    ],
    minBet: 100,
    maxBet: 2000,
    houseEdge: 7,
    autoRebalance: true,
    status: 'active',
    // Legacy fields
    sideA: 'Giannis',
    sideB: 'Jokic',
    oddsA: 2.0,
    oddsB: 2.0,
    chipAmount: 200,
    usersOnA: 15,
    usersOnB: 14,
    chipsOnA: 3000,
    chipsOnB: 2800,
  },
  {
    id: 3,
    bookId: 1,
    title: 'Will Dave show up on time?',
    description: 'Friday meeting at 9am',
    type: 'Funny',
    outcomes: [
      { id: '1', name: 'Yes', odds: 1.5, users: 20, totalChips: 3000 },
      { id: '2', name: 'No', odds: 3.0, users: 5, totalChips: 750 },
    ],
    minBet: 50,
    maxBet: 500,
    houseEdge: 7,
    autoRebalance: true,
    status: 'active',
    sideA: 'Yes',
    sideB: 'No',
    oddsA: 1.5,
    oddsB: 3.0,
    chipAmount: 150,
    usersOnA: 20,
    usersOnB: 5,
    chipsOnA: 3000,
    chipsOnB: 750,
  },
  {
    id: 4,
    bookId: 1,
    title: 'Weather tomorrow',
    description: 'Will it rain in LA tomorrow?',
    type: 'IRL',
    outcomes: [
      { id: '1', name: 'Rain', odds: 1.7, users: 8, totalChips: 800 },
      { id: '2', name: 'No Rain', odds: 2.3, users: 6, totalChips: 600 },
    ],
    minBet: 50,
    maxBet: 1000,
    houseEdge: 7,
    autoRebalance: true,
    status: 'active',
    sideA: 'Rain',
    sideB: 'No Rain',
    oddsA: 1.7,
    oddsB: 2.3,
    chipAmount: 100,
    usersOnA: 8,
    usersOnB: 6,
    chipsOnA: 800,
    chipsOnB: 600,
  },
  {
    id: 5,
    bookId: 1,
    title: 'Custom prediction test',
    description: 'Random prediction for testing',
    type: 'Custom',
    outcomes: [
      { id: '1', name: 'Option A', odds: 2.5, users: 10, totalChips: 2500 },
      { id: '2', name: 'Option B', odds: 1.6, users: 18, totalChips: 4500 },
    ],
    minBet: 100,
    maxBet: 1000,
    houseEdge: 7,
    autoRebalance: true,
    status: 'active',
    sideA: 'Option A',
    sideB: 'Option B',
    oddsA: 2.5,
    oddsB: 1.6,
    chipAmount: 250,
    usersOnA: 10,
    usersOnB: 18,
    chipsOnA: 2500,
    chipsOnB: 4500,
  },
  {
    id: 6,
    bookId: 2,
    title: 'Best Picture Oscar 2026',
    description: 'Which film will win Best Picture?',
    type: 'Sports',
    outcomes: [
      { id: '1', name: 'The Director', odds: 1.7, users: 8, totalChips: 800 },
      { id: '2', name: 'Lost Highway', odds: 2.3, users: 6, totalChips: 600 },
    ],
    minBet: 50,
    maxBet: 500,
    houseEdge: 7,
    autoRebalance: true,
    status: 'active',
    sideA: 'The Director',
    sideB: 'Lost Highway',
    oddsA: 1.7,
    oddsB: 2.3,
    chipAmount: 100,
    usersOnA: 8,
    usersOnB: 6,
    chipsOnA: 800,
    chipsOnB: 600,
  },
];

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('home');
  const [selectedBookId, setSelectedBookId] = useState<number | null>(null);
  const [selectedBetId, setSelectedBetId] = useState<number | null>(null);
  
  // State management for user, books, and bets
  const [user, setUser] = useState<User>(mockUser);
  const [books, setBooks] = useState<Book[]>(mockBooks);
  const [bets, setBets] = useState<Bet[]>(mockBets);
  const [players, setPlayers] = useState<Player[]>(mockPlayers);
  const [userRoles, setUserRoles] = useState<UserRole[]>(mockUserRoles);
  const [nextBetId, setNextBetId] = useState(7);
  const [nextBookId, setNextBookId] = useState(4);

  const navigateToBook = (bookId: number) => {
    setSelectedBookId(bookId);
    setCurrentScreen('book');
  };

  const navigateToBetDetails = (betId: number) => {
    setSelectedBetId(betId);
    setCurrentScreen('bet-details');
  };

  const navigateToCreateBet = () => {
    setCurrentScreen('create-bet');
  };

  const navigateToProfile = () => {
    setCurrentScreen('profile');
  };

  const navigateToHome = () => {
    setCurrentScreen('home');
  };

  const navigateToCreateBook = () => {
    setCurrentScreen('create-book');
  };

  const navigateToBookSettings = () => {
    setCurrentScreen('book-settings');
  };

  const navigateToClubData = () => {
    setCurrentScreen('club-data');
  };

  const saveBookSettings = (settings: BookSettings) => {
    if (selectedBookId === null) return;
    
    setBooks(books.map(book => 
      book.id === selectedBookId
        ? { ...book, name: settings.name, logo: settings.logo }
        : book
    ));
    
    // In a real app, you would save theme, pinned message, etc.
    // For now, just update the name and logo
  };

  const deleteBook = () => {
    if (selectedBookId === null) return;

    // Remove the book
    setBooks(books.filter(book => book.id !== selectedBookId));

    // Remove all bets associated with this book
    setBets(bets.filter(bet => bet.bookId !== selectedBookId));

    // Remove all players associated with this book
    setPlayers(players.filter(player => player.bookId !== selectedBookId));

    // Remove user role for this book
    setUserRoles(userRoles.filter(role => role.bookId !== selectedBookId));

    // Remove book from user's joined books
    setUser({
      ...user,
      booksJoined: user.booksJoined.filter(id => id !== selectedBookId),
    });

    // Show success message and navigate home
    toast.success('Book deleted successfully');
    setSelectedBookId(null);
    setCurrentScreen('home');
  };

  const createBook = (bookData: { name: string; logo: string }) => {
    const bookId = `BC${Math.random().toString(36).substring(2, 6).toUpperCase()}`;
    const newBook: Book = {
      id: nextBookId,
      bookId: bookId,
      name: bookData.name,
      logo: bookData.logo,
      members: 1,
      activeBets: 0,
      ownerId: user.id,
      ownerName: user.username,
      totalRedChips: 0,
      totalBlueChips: 0,
      defaultHouseEdge: 7, // Default 7% house edge
    };

    setBooks([...books, newBook]);
    setUser({
      ...user,
      booksJoined: [...user.booksJoined, nextBookId],
    });
    setUserRoles([...userRoles, { bookId: nextBookId, role: 'Manager' }]);
    
    // Add the owner as a player in the book
    const newPlayer: Player = {
      id: players.length + 1,
      username: user.username,
      avatar: user.avatar,
      redChips: 0,
      bookId: nextBookId,
    };
    setPlayers([...players, newPlayer]);
    
    setNextBookId(nextBookId + 1);
    
    // Navigate to the new book after a short delay to see success screen
    setTimeout(() => {
      setSelectedBookId(newBook.id);
      setCurrentScreen('book');
    }, 2000);
  };

  const addBet = (newBet: Omit<Bet, 'id' | 'status'>) => {
    const bet: Bet = {
      ...newBet,
      id: nextBetId,
      status: 'active',
      // Add legacy fields if they don't exist for backward compatibility
      usersOnA: newBet.usersOnA || 0,
      usersOnB: newBet.usersOnB || 0,
      chipsOnA: newBet.chipsOnA || 0,
      chipsOnB: newBet.chipsOnB || 0,
    };
    setBets([...bets, bet]);
    setNextBetId(nextBetId + 1);
    
    // Update book's active bets count
    setBooks(books.map(book => 
      book.id === newBet.bookId 
        ? { ...book, activeBets: book.activeBets + 1 }
        : book
    ));
    
    return bet.id;
  };

  const placeBet = (betId: number, outcomeId: string, amount: number) => {
    const bet = bets.find(b => b.id === betId);
    if (!bet) return false;

    // Get player for this book
    const player = players.find(p => p.bookId === bet.bookId && p.username === user.username);
    if (!player) return false;

    // Check if player has enough chips
    if (player.redChips < amount) {
      return false;
    }

    // Update bet outcomes
    setBets(bets.map(b => {
      if (b.id === betId) {
        return {
          ...b,
          outcomes: b.outcomes.map(outcome => 
            outcome.id === outcomeId
              ? { ...outcome, users: outcome.users + 1, totalChips: outcome.totalChips + amount }
              : outcome
          ),
          // Update legacy fields for backward compatibility
          usersOnA: outcomeId === '1' ? (b.usersOnA || 0) + 1 : b.usersOnA,
          usersOnB: outcomeId === '2' ? (b.usersOnB || 0) + 1 : b.usersOnB,
          chipsOnA: outcomeId === '1' ? (b.chipsOnA || 0) + amount : b.chipsOnA,
          chipsOnB: outcomeId === '2' ? (b.chipsOnB || 0) + amount : b.chipsOnB,
        };
      }
      return b;
    }));

    // Deduct chips from player
    setPlayers(players.map(p =>
      p.id === player.id
        ? { ...p, redChips: p.redChips - amount }
        : p
    ));

    // Update user's red chips if they're the current user
    if (player.username === user.username) {
      setUser({
        ...user,
        redChips: user.redChips - amount,
      });
    }

    return true;
  };

  const sendChipsToPlayer = (bookId: number, playerId: number, amount: number) => {
    const book = books.find(c => c.id === bookId);
    if (!book || book.totalBlueChips < amount) return false;

    // Deduct from book's blue chips
    setBooks(books.map(c => 
      c.id === bookId 
        ? { ...c, totalBlueChips: c.totalBlueChips - amount, totalRedChips: c.totalRedChips + amount }
        : c
    ));

    // Add to player's red chips
    setPlayers(players.map(p => 
      p.id === playerId && p.bookId === bookId
        ? { ...p, redChips: p.redChips + amount }
        : p
    ));

    return true;
  };

  const claimChipsFromPlayer = (bookId: number, playerId: number, amount: number) => {
    const player = players.find(p => p.id === playerId && p.bookId === bookId);
    if (!player || player.redChips < amount) return false;

    // Deduct from player's red chips
    setPlayers(players.map(p => 
      p.id === playerId && p.bookId === bookId
        ? { ...p, redChips: p.redChips - amount }
        : p
    ));

    // Add to book's blue chips
    setBooks(books.map(c => 
      c.id === bookId 
        ? { ...c, totalBlueChips: c.totalBlueChips + amount, totalRedChips: c.totalRedChips - amount }
        : c
    ));

    return true;
  };

  const renderScreen = () => {
    switch (currentScreen) {
      case 'home':
        return (
          <HomeScreen
            user={user}
            books={books}
            userRoles={userRoles}
            onNavigateToBook={navigateToBook}
            onNavigateToProfile={navigateToProfile}
            onNavigateToScreen={setCurrentScreen}
            onNavigateToCreateBook={navigateToCreateBook}
          />
        );
      case 'create-book':
        return (
          <CreateBookScreen
            onNavigateBack={navigateToHome}
            onCreateBook={createBook}
          />
        );
      case 'book':
        return (
          <ClubPage
            book={books.find((c) => c.id === selectedBookId)!}
            bets={bets.filter((b) => b.bookId === selectedBookId)}
            players={players.filter((p) => p.bookId === selectedBookId)}
            user={user}
            userRole={userRoles.find(r => r.bookId === selectedBookId)?.role || 'Player'}
            onNavigateBack={navigateToHome}
            onNavigateToBetDetails={navigateToBetDetails}
            onNavigateToCreateBet={navigateToCreateBet}
            onNavigateToBookSettings={navigateToBookSettings}
            onNavigateToClubData={navigateToClubData}
            onSendChips={sendChipsToPlayer}
            onClaimChips={claimChipsFromPlayer}
          />
        );
      case 'book-settings':
        return (
          <BookSettingsScreen
            book={books.find((c) => c.id === selectedBookId)!}
            isOwner={books.find((c) => c.id === selectedBookId)?.ownerId === user.id}
            onNavigateBack={() => setCurrentScreen('book')}
            onSaveSettings={saveBookSettings}
            onDeleteBook={deleteBook}
          />
        );
      case 'create-bet':
        const selectedBook = books.find((b) => b.id === selectedBookId);
        return (
          <CreateBetScreen
            bookId={selectedBookId!}
            defaultHouseEdge={selectedBook?.defaultHouseEdge || 7}
            onNavigateBack={() => setCurrentScreen('book')}
            onCreateBet={addBet}
          />
        );
      case 'bet-details':
        const currentBet = bets.find((b) => b.id === selectedBetId)!;
        const currentPlayer = players.find(p => p.bookId === currentBet.bookId && p.username === user.username);
        return (
          <BetDetailsScreen
            bet={currentBet}
            userRedChips={currentPlayer?.redChips || 0}
            isOwner={books.find((c) => c.id === currentBet.bookId)?.ownerId === user.id}
            onNavigateBack={() => setCurrentScreen('book')}
            onPlaceBet={placeBet}
          />
        );
      case 'profile':
        return <ProfileScreen user={user} books={books} onNavigateBack={navigateToHome} />;
      case 'club-data':
        return (
          <ClubDataScreen
            bookId={selectedBookId?.toString() || ''}
            bookName={books.find((c) => c.id === selectedBookId)?.name || ''}
            onNavigateBack={() => setCurrentScreen('book')}
          />
        );
      case 'bets':
      case 'activity':
        return (
          <div className="min-h-screen flex items-center justify-center text-white">
            <div className="text-center">
              <p className="text-2xl mb-4">Coming Soon</p>
              <Button onClick={navigateToHome}>Back to Home</Button>
            </div>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-900 via-blue-800 to-blue-950">
      <div className="mx-auto max-w-md min-h-screen">{renderScreen()}</div>
      <Toaster />
    </div>
  );
}