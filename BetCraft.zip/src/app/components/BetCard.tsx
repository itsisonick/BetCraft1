import { Bet } from '../App';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Coins, Users } from 'lucide-react';
import { Badge } from './ui/badge';

interface BetCardProps {
  bet: Bet;
  onViewDetails: () => void;
}

const betTypeColors = {
  Sports: 'bg-blue-500/20 text-blue-400 border-blue-400/30',
  IRL: 'bg-cyan-500/20 text-cyan-400 border-cyan-400/30',
  Funny: 'bg-purple-500/20 text-purple-400 border-purple-400/30',
  Custom: 'bg-violet-500/20 text-violet-400 border-violet-400/30',
};

export default function BetCard({ bet, onViewDetails }: BetCardProps) {
  const totalParticipants = bet.outcomes.reduce((sum, outcome) => sum + outcome.users, 0);
  const totalChips = bet.outcomes.reduce((sum, outcome) => sum + outcome.totalChips, 0);

  // Get top 2 outcomes for display
  const displayOutcomes = bet.outcomes.slice(0, 2);

  return (
    <Card className="relative overflow-hidden border border-blue-400/20 hover:border-blue-400/40 transition-all duration-300 shadow-lg hover:shadow-blue-500/20" style={{
      background: 'rgba(12, 27, 53, 0.6)',
      backdropFilter: 'blur(8px)'
    }}>
      {/* Subtle glow effect on hover */}
      <div className="absolute inset-0 bg-gradient-to-r from-blue-500/0 via-blue-500/5 to-purple-500/0 opacity-0 hover:opacity-100 transition-opacity duration-300"></div>
      
      {/* Inner shadow for depth */}
      <div className="absolute inset-0 rounded-lg shadow-inner" style={{
        boxShadow: 'inset 0 2px 4px rgba(0, 0, 0, 0.3)'
      }}></div>

      <div className="relative p-4">
        {/* Title and Type Badge */}
        <div className="mb-3">
          <div className="flex items-start justify-between gap-2 mb-2">
            <h3 className="text-white flex-1 leading-snug pr-1">{bet.title}</h3>
            <Badge className={`${betTypeColors[bet.type]} text-xs px-2 py-0.5 flex-shrink-0`}>
              {bet.type}
            </Badge>
          </div>
          <p className="text-sm text-blue-200/60 leading-relaxed">{bet.description}</p>
        </div>

        {/* Odds Display - Rectangular buttons with gradient and glow */}
        <div className="mb-3">
          <div className={`grid ${bet.outcomes.length > 2 ? 'grid-cols-1' : 'grid-cols-2'} gap-2`}>
            {displayOutcomes.map((outcome, index) => (
              <button
                key={outcome.id}
                className="relative group rounded-lg overflow-hidden transition-all hover:scale-[1.02]"
              >
                {/* Gradient background */}
                <div className={`absolute inset-0 ${
                  index === 0
                    ? 'bg-gradient-to-br from-blue-500 to-indigo-600'
                    : 'bg-gradient-to-br from-indigo-500 to-purple-600'
                } opacity-80 group-hover:opacity-100 transition-opacity`}></div>
                {/* Neon glow */}
                <div className={`absolute inset-0 ${
                  index === 0 ? 'bg-blue-500/50' : 'bg-indigo-500/50'
                } blur-md group-hover:blur-lg transition-all opacity-0 group-hover:opacity-100`}></div>
                <div className={`relative p-3 border ${
                  index === 0 ? 'border-blue-400/30' : 'border-indigo-400/30'
                } rounded-lg`}>
                  <div className="text-xs text-blue-100 mb-1 uppercase tracking-wide truncate">
                    {outcome.name}
                  </div>
                  <div className="flex items-center justify-center gap-1">
                    <div className="text-xl text-white">{outcome.odds.toFixed(1)}</div>
                    <div className="text-xs text-blue-200">x</div>
                  </div>
                  {outcome.odds < 2.0 && <div className="text-xs text-yellow-300/70 mt-0.5">🔥 Favored</div>}
                  {outcome.odds >= 2.5 && <div className="text-xs text-blue-300/70 mt-0.5">🧊 Underdog</div>}
                </div>
              </button>
            ))}
            {bet.outcomes.length > 2 && (
              <div className="text-xs text-center text-blue-300/70 py-1">
                +{bet.outcomes.length - 2} more option{bet.outcomes.length - 2 !== 1 ? 's' : ''}
              </div>
            )}
          </div>
        </div>

        {/* Stats Row */}
        <div className="flex items-center justify-between mb-3 text-xs px-1">
          <div className="flex items-center gap-1.5">
            <span className="text-sm">🔴</span>
            <span className="text-red-400">{bet.minBet}-{bet.maxBet}</span>
            <span className="text-blue-200/50">chips</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Users className="h-3.5 w-3.5 text-blue-400" />
            <span className="text-white">{totalParticipants}</span>
            <span className="text-blue-200/50">joined</span>
          </div>
        </div>

        {/* Pool indicator */}
        {totalChips > 0 && (
          <div className="mb-3 text-xs text-center bg-red-500/10 border border-red-400/20 rounded px-2 py-1">
            <span className="text-red-300">🔴 Pool: {totalChips.toLocaleString()} chips</span>
          </div>
        )}

        {/* Action Buttons */}
        <div className="grid grid-cols-2 gap-2">
          <Button
            onClick={onViewDetails}
            variant="outline"
            size="sm"
            className="bg-transparent border-white/40 text-white hover:bg-white/10 hover:border-white/60 transition-all h-9"
          >
            Details
          </Button>
          <Button
            onClick={onViewDetails}
            size="sm"
            className="relative bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white border-0 shadow-lg shadow-blue-500/30 hover:shadow-blue-500/50 transition-all h-9 hover:scale-[1.02]"
          >
            <span className="relative z-10">Place Bet</span>
            {/* Pulse animation on hover */}
            <div className="absolute inset-0 bg-blue-400/20 rounded-md opacity-0 group-hover:opacity-100 animate-pulse"></div>
          </Button>
        </div>
      </div>
    </Card>
  );
}
