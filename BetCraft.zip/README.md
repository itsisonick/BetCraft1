
  # BetCraft

  This is a code bundle for BetCraft. The original project is available at https://www.figma.com/design/MAJ4SrrpkxeCIbYUTW04Rj/BetCraft.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  