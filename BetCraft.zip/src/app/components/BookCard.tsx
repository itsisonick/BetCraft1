import { Book } from '../App';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Users, TrendingUp } from 'lucide-react';

interface BookCardProps {
  book: Book;
  role: 'Manager' | 'Agent' | 'Player';
  onClick: () => void;
}

export default function BookCard({ book, role, onClick }: BookCardProps) {
  const getRoleBadgeColor = () => {
    switch (role) {
      case 'Manager':
        return 'bg-yellow-500/20 text-yellow-300 border-yellow-400/40';
      case 'Agent':
        return 'bg-purple-500/20 text-purple-300 border-purple-400/40';
      case 'Player':
        return 'bg-blue-500/20 text-blue-300 border-blue-400/40';
    }
  };

  return (
    <Card
      className="relative overflow-hidden p-6 bg-gradient-to-br from-slate-800/60 via-slate-700/40 to-slate-800/60 backdrop-blur-sm border border-blue-400/20 hover:border-blue-400/50 transition-all duration-300 cursor-pointer shadow-xl hover:shadow-blue-500/30 active:scale-[0.98] group h-full"
      onClick={onClick}
    >
      {/* Animated glow effect */}
      <div className="absolute inset-0 bg-gradient-to-r from-blue-500/0 via-purple-500/10 to-blue-500/0 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
      <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-blue-500/5 to-purple-500/5 blur-xl group-hover:blur-2xl transition-all duration-300"></div>
      
      <div className="relative flex flex-col gap-4 h-full">
        {/* Top Section: Logo and Role Badge */}
        <div className="flex items-start justify-between">
          {/* Square Logo Container with neon glow */}
          <div className="relative w-20 h-20 bg-gradient-to-br from-blue-500/20 to-purple-500/20 backdrop-blur-sm rounded-xl flex items-center justify-center border border-blue-400/30 flex-shrink-0 shadow-lg shadow-blue-500/20">
            <div className="absolute inset-0 rounded-xl bg-gradient-to-br from-blue-400/20 to-purple-400/20 blur group-hover:blur-md transition-all"></div>
            <div className="relative text-5xl">{book.logo}</div>
          </div>
          
          <Badge className={`${getRoleBadgeColor()} text-xs px-3 py-1`}>
            {role}
          </Badge>
        </div>
        
        {/* Book Name */}
        <div>
          <h3 className="text-xl text-white mb-1">{book.name}</h3>
          <p className="text-xs text-blue-300/50">ID: {book.bookId}</p>
        </div>
        
        {/* Stats */}
        <div className="flex items-center gap-6 text-sm mt-auto pt-4 border-t border-white/10">
          <div className="flex items-center gap-2 text-blue-200">
            <Users className="h-4 w-4" />
            <div>
              <div className="text-lg text-white">{book.members}</div>
              <div className="text-xs text-blue-300/60">members</div>
            </div>
          </div>
          <div className="flex items-center gap-2 text-green-400">
            <TrendingUp className="h-4 w-4" />
            <div>
              <div className="text-lg text-white">{book.activeBets}</div>
              <div className="text-xs text-green-300/60">active bets</div>
            </div>
          </div>
        </div>
      </div>
    </Card>
  );
}
