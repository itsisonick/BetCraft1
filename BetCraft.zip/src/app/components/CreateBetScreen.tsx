import { Bet, BetOutcome } from '../App';
import { ArrowLeft, Plus, Trash2, Info, GripVertical } from 'lucide-react';
import { toast } from 'sonner';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Slider } from './ui/slider';
import { ScrollArea } from './ui/scroll-area';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from './ui/tooltip';
import { Badge } from './ui/badge';

interface CreateBetScreenProps {
  bookId: number;
  defaultHouseEdge: number;
  onNavigateBack: () => void;
  onCreateBet: (newBet: Omit<Bet, 'id' | 'status'>) => number;
}

type Step = 1 | 2 | 3;

export default function CreateBetScreen({ bookId, defaultHouseEdge, onNavigateBack, onCreateBet }: CreateBetScreenProps) {
  const [step, setStep] = useState<Step>(1);

  // Mode Selection
  const [betMode, setBetMode] = useState<'book' | 'prediction-market'>('book');

  // Step 1: Basic Setup
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<'Sports' | 'IRL' | 'Funny' | 'Custom'>('Sports');
  const [minBet, setMinBet] = useState('50');
  const [maxBet, setMaxBet] = useState('1000');
  const [outcomes, setOutcomes] = useState<Array<{ id: string; name: string }>>([
    { id: '1', name: '' },
    { id: '2', name: '' },
  ]);

  // Prediction Market Mode fields
  const [startingPrice, setStartingPrice] = useState(50);
  const [creatorFee, setCreatorFee] = useState(2);
  const [eventDate, setEventDate] = useState('');
  const [tradingDeadline, setTradingDeadline] = useState('');
  
  // Multi-Outcome Prediction Market fields
  const [marketOutcomes, setMarketOutcomes] = useState<Array<{ id: string; name: string; startPct: string }>>([ 
    { id: '1', name: '', startPct: '50.0' },
    { id: '2', name: '', startPct: '50.0' },
  ]);
  const [hasManuallyEditedPct, setHasManuallyEditedPct] = useState(false);

  // Step 2: Odds (Book Mode only)
  const [probabilitySlider, setProbabilitySlider] = useState(50);
  const [houseEdge, setHouseEdge] = useState(defaultHouseEdge); // Configurable house edge (3-10%)
  const [showAdvancedSettings, setShowAdvancedSettings] = useState(false);
  
  // Custom probability inputs (for direct percentage entry)
  const [customProbA, setCustomProbA] = useState('50');
  const [customProbB, setCustomProbB] = useState('50');
  const [usingCustomProb, setUsingCustomProb] = useState(false);

  // Step 3: Advanced
  const [autoRebalance, setAutoRebalance] = useState(true);

  // Add outcome
  const addOutcome = () => {
    if (outcomes.length >= 5) {
      toast.error('Maximum 5 outcomes allowed');
      return;
    }
    setOutcomes([...outcomes, { id: Date.now().toString(), name: '' }]);
  };

  // Remove outcome
  const removeOutcome = (id: string) => {
    if (outcomes.length <= 2) {
      toast.error('Minimum 2 outcomes required');
      return;
    }
    setOutcomes(outcomes.filter((o) => o.id !== id));
  };

  // Multi-Outcome Market functions
  const addMarketOutcome = () => {
    if (marketOutcomes.length >= 5) {
      toast.error('Maximum 5 outcomes allowed');
      return;
    }
    const newOutcome = { id: Date.now().toString(), name: '', startPct: '0.0' };
    setMarketOutcomes([...marketOutcomes, newOutcome]);
    
    // Auto-distribute if user hasn't manually edited
    if (!hasManuallyEditedPct) {
      autoDistributePercentages([...marketOutcomes, newOutcome]);
    }
  };

  const removeMarketOutcome = (id: string) => {
    if (marketOutcomes.length <= 2) {
      toast.error('Minimum 2 outcomes required');
      return;
    }
    const newOutcomes = marketOutcomes.filter((o) => o.id !== id);
    setMarketOutcomes(newOutcomes);
    
    // Auto-distribute if user hasn't manually edited
    if (!hasManuallyEditedPct) {
      autoDistributePercentages(newOutcomes);
    }
  };

  const updateMarketOutcomeName = (id: string, name: string) => {
    setMarketOutcomes(marketOutcomes.map((o) => (o.id === id ? { ...o, name } : o)));
  };

  const updateMarketOutcomePct = (id: string, value: string) => {
    // Strip % if typed
    let cleanValue = value.replace('%', '');
    
    // Block negatives
    if (cleanValue.startsWith('-')) {
      return;
    }
    
    // Accept 0-100, up to 1 decimal
    const numValue = parseFloat(cleanValue);
    if (cleanValue !== '' && (isNaN(numValue) || numValue < 0 || numValue > 100)) {
      return;
    }
    
    // Limit to 1 decimal place
    if (cleanValue.includes('.')) {
      const parts = cleanValue.split('.');
      if (parts[1].length > 1) {
        cleanValue = `${parts[0]}.${parts[1].substring(0, 1)}`;
      }
    }
    
    setMarketOutcomes(marketOutcomes.map((o) => (o.id === id ? { ...o, startPct: cleanValue } : o)));
    setHasManuallyEditedPct(true);
  };

  const autoDistributePercentages = (outcomesList = marketOutcomes) => {
    const n = outcomesList.length;
    const evenShare = Math.floor((100 / n) * 10) / 10; // Round to 0.1%
    const remainder = Math.round((100 - evenShare * n) * 10) / 10;
    
    const distributed = outcomesList.map((o, index) => ({
      ...o,
      startPct: index === 0 ? (evenShare + remainder).toFixed(1) : evenShare.toFixed(1),
    }));
    
    setMarketOutcomes(distributed);
  };

  const calculateTotalPct = () => {
    return marketOutcomes.reduce((sum, o) => {
      const val = parseFloat(o.startPct);
      return sum + (isNaN(val) ? 0 : val);
    }, 0);
  };

  const moveMarketOutcome = (index: number, direction: 'up' | 'down') => {
    const newOutcomes = [...marketOutcomes];
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    
    if (targetIndex < 0 || targetIndex >= newOutcomes.length) {
      return;
    }
    
    [newOutcomes[index], newOutcomes[targetIndex]] = [newOutcomes[targetIndex], newOutcomes[index]];
    setMarketOutcomes(newOutcomes);
  };

  // Update outcome name
  const updateOutcomeName = (id: string, name: string) => {
    setOutcomes(outcomes.map((o) => (o.id === id ? { ...o, name } : o)));
  };

  // Handle custom probability input
  const handleCustomProbAChange = (value: string) => {
    // Allow empty or valid numbers only
    if (value === '' || /^\d*\.?\d*$/.test(value)) {
      const numVal = parseFloat(value);
      if (value !== '' && (numVal < 0 || numVal > 100)) {
        return;
      }
      setCustomProbA(value);
      setUsingCustomProb(true);
      
      // Auto-calculate complement if valid
      if (value !== '' && !isNaN(numVal)) {
        const complement = Math.max(0, Math.min(100, 100 - numVal));
        setCustomProbB(complement.toFixed(1));
      }
    }
  };

  const handleCustomProbBChange = (value: string) => {
    // Allow empty or valid numbers only
    if (value === '' || /^\d*\.?\d*$/.test(value)) {
      const numVal = parseFloat(value);
      if (value !== '' && (numVal < 0 || numVal > 100)) {
        return;
      }
      setCustomProbB(value);
      setUsingCustomProb(true);
      
      // Auto-calculate complement if valid
      if (value !== '' && !isNaN(numVal)) {
        const complement = Math.max(0, Math.min(100, 100 - numVal));
        setCustomProbA(complement.toFixed(1));
      }
    }
  };

  const handleSliderChange = (value: number[]) => {
    setProbabilitySlider(value[0]);
    setUsingCustomProb(false);
    // Update custom inputs to match slider
    setCustomProbA(value[0].toString());
    setCustomProbB((100 - value[0]).toString());
  };

  // Calculate odds based on probability
  const calculateOdds = () => {
    if (outcomes.length !== 2) {
      // For now, only support 2 outcomes
      return outcomes.map((o) => ({ ...o, odds: 2.0 }));
    }

    // Use custom probabilities if active, otherwise use slider
    let prob: number;
    if (usingCustomProb) {
      const probAVal = parseFloat(customProbA);
      prob = !isNaN(probAVal) ? probAVal / 100 : 0.5;
    } else {
      prob = probabilitySlider / 100;
    }
    
    const probB = 1 - prob;

    // Apply house edge (reduce payouts)
    const edgeMultiplier = 1 - houseEdge / 100;

    let oddsA = prob > 0 ? (1 / prob) * edgeMultiplier : 1.01;
    let oddsB = probB > 0 ? (1 / probB) * edgeMultiplier : 1.01;

    // Cap very low probabilities
    if (prob >= 0.95) {
      oddsA = 1.05;
    }
    if (probB >= 0.95) {
      oddsB = 1.05;
    }

    // Round to 2 decimals
    oddsA = Math.round(oddsA * 100) / 100;
    oddsB = Math.round(oddsB * 100) / 100;

    return [
      { ...outcomes[0], odds: oddsA },
      { ...outcomes[1], odds: oddsB },
    ];
  };

  const oddsPreview = calculateOdds();
  
  // Check if custom probabilities total 100%
  const customProbsValid = () => {
    if (!usingCustomProb) return true;
    const totalProb = parseFloat(customProbA || '0') + parseFloat(customProbB || '0');
    return Math.abs(totalProb - 100) < 0.1;
  };

  // Calculate estimated book profit
  const calculateEstimatedProfit = () => {
    const totalWagered = 1000; // Example: per 1000 chips wagered
    const profit = totalWagered * (houseEdge / 100);
    return Math.round(profit);
  };

  // Validate step 1
  const validateStep1 = () => {
    if (!title.trim()) {
      toast.error('Please enter a bet title');
      return false;
    }
    
    if (betMode === 'book') {
      if (outcomes.some((o) => !o.name.trim())) {
        toast.error('Please name all outcomes');
        return false;
      }
      if (parseInt(minBet) <= 0 || parseInt(maxBet) <= 0) {
        toast.error('Bet amounts must be greater than 0');
        return false;
      }
      if (parseInt(minBet) >= parseInt(maxBet)) {
        toast.error('Maximum bet must be greater than minimum bet');
        return false;
      }
    } else {
      // Prediction Market validation
      if (marketOutcomes.some((o) => !o.name.trim())) {
        toast.error('Please name all outcomes');
        return false;
      }
      
      const totalPct = calculateTotalPct();
      if (Math.abs(totalPct - 100) > 0.01) {
        toast.error('Total percentages must equal 100%');
        return false;
      }
      
      if (!eventDate) {
        toast.error('Please set an event date');
        return false;
      }
      if (!tradingDeadline) {
        toast.error('Please set a trading deadline');
        return false;
      }
      if (new Date(tradingDeadline) >= new Date(eventDate)) {
        toast.error('Trading deadline must be before event date');
        return false;
      }
    }
    return true;
  };

  // Navigate to next step
  const goToStep2 = () => {
    if (validateStep1()) {
      setStep(2);
    }
  };

  // Navigate to preview
  const goToStep3 = () => {
    if (validateStep1()) {
      setStep(3);
    }
  };

  // Publish bet
  const publishBet = () => {
    let finalOutcomes: BetOutcome[];
    
    if (betMode === 'prediction-market') {
      // Prediction markets use multi-outcome with starting percentages
      finalOutcomes = marketOutcomes.map((o) => ({
        id: o.id,
        name: o.name,
        odds: parseFloat(o.startPct) / 100,
        users: 0,
        totalChips: 0,
      }));
    } else {
      // Book mode
      finalOutcomes = useRecommendedOdds
        ? oddsPreview.map((o) => ({
            id: o.id,
            name: o.name,
            odds: o.odds,
            users: 0,
            totalChips: 0,
          }))
        : outcomes.map((o) => ({
            id: o.id,
            name: o.name,
            odds: parseFloat(customOdds[o.id] || '2.0'),
            users: 0,
            totalChips: 0,
          }));
    }

    onCreateBet({
      bookId,
      title,
      description: betMode === 'prediction-market' 
        ? `${category} · Prediction Market` 
        : `${category} bet`,
      type: category,
      outcomes: finalOutcomes,
      minBet: betMode === 'book' ? parseInt(minBet) : 1,
      maxBet: betMode === 'book' ? parseInt(maxBet) : 999999,
      houseEdge: betMode === 'book' && useRecommendedOdds ? houseEdge : creatorFee,
      autoRebalance: betMode === 'book' ? autoRebalance : true,
    });

    toast.success(betMode === 'prediction-market' ? '🎉 Market created successfully!' : '🎉 Bet published successfully!');
    setTimeout(() => {
      onNavigateBack();
    }, 500);
  };

  return (
    <div className="min-h-screen flex flex-col text-white" style={{
      background: 'linear-gradient(to bottom, #05122B 0%, #0C1B35 100%)'
    }}>
      {/* Header */}
      <div className="p-6 pb-8 bg-gradient-to-r from-blue-600/20 to-purple-600/20 border-b border-blue-400/20">
        <div className="flex items-center justify-between mb-6">
          <Button
            variant="ghost"
            size="icon"
            onClick={step === 1 ? onNavigateBack : () => setStep((step - 1) as Step)}
            className="text-white hover:bg-white/10"
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div className="text-sm text-blue-200">
            Step {step} of 3
          </div>
        </div>
        <h1 className="text-2xl">
          {step === 1 && 'Create New Bet'}
          {step === 2 && 'Set Odds'}
          {step === 3 && 'Preview & Publish'}
        </h1>
        <p className="text-sm text-blue-200/70 mt-1">
          {step === 1 && 'Set up your bet in under 30 seconds'}
          {step === 2 && 'Who\'s more likely to win?'}
          {step === 3 && 'Review your bet before publishing'}
        </p>
      </div>

      <ScrollArea className="flex-1">
        <div className="p-6 space-y-6 pb-24">
          {/* Step 1: Basic Setup */}
          {step === 1 && (
            <>
              {/* Bet Title */}
              <div className="space-y-2">
                <Label htmlFor="title" className="text-white">
                  Bet Title
                </Label>
                <Input
                  id="title"
                  placeholder="e.g., Who wins tonight's game?"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="bg-white/5 border-blue-400/30 text-white placeholder:text-white/40"
                />
              </div>

              {/* Mode Selector */}
              <div className="space-y-3">
                <Label className="text-white">Bet Type</Label>
                <p className="text-xs text-blue-200/60 -mt-1">
                  Select your bet type: Book Mode (house-controlled) or Prediction Market Mode (player trading)
                </p>
                <div className="grid grid-cols-2 gap-2">
                  <Button
                    variant="outline"
                    onClick={() => setBetMode('book')}
                    className={`${
                      betMode === 'book'
                        ? 'bg-blue-500/20 border-blue-400 text-white'
                        : 'bg-white/5 border-blue-400/30 text-blue-200'
                    } hover:bg-blue-500/10`}
                  >
                    🔘 Book Mode
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => setBetMode('prediction-market')}
                    className={`${
                      betMode === 'prediction-market'
                        ? 'bg-blue-500/20 border-blue-400 text-white'
                        : 'bg-white/5 border-blue-400/30 text-blue-200'
                    } hover:bg-blue-500/10`}
                  >
                    🔘 Prediction Market
                  </Button>
                </div>
              </div>

              {/* Category */}
              <div className="space-y-2">
                <Label className="text-white">Category</Label>
                <div className="grid grid-cols-2 gap-2">
                  {(['Sports', 'IRL', 'Funny', 'Custom'] as const).map((cat) => (
                    <Button
                      key={cat}
                      variant="outline"
                      onClick={() => setCategory(cat)}
                      className={`${
                        category === cat
                          ? 'bg-blue-500/20 border-blue-400 text-white'
                          : 'bg-white/5 border-blue-400/30 text-blue-200'
                      } hover:bg-blue-500/10`}
                    >
                      {cat}
                    </Button>
                  ))}
                </div>
              </div>

              {/* Book Mode: Min/Max Bet */}
              {betMode === 'book' && (
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="minBet" className="text-white flex items-center gap-1">
                      <span className="text-sm">🔴</span>
                      Minimum Bet
                    </Label>
                    <Input
                      id="minBet"
                      type="number"
                      placeholder="50"
                      value={minBet}
                      onChange={(e) => setMinBet(e.target.value)}
                      className="bg-white/5 border-red-400/30 text-white placeholder:text-white/40"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="maxBet" className="text-white flex items-center gap-1">
                      <span className="text-sm">🔴</span>
                      Maximum Bet
                    </Label>
                    <Input
                      id="maxBet"
                      type="number"
                      placeholder="1000"
                      value={maxBet}
                      onChange={(e) => setMaxBet(e.target.value)}
                      className="bg-white/5 border-red-400/30 text-white placeholder:text-white/40"
                    />
                  </div>
                </div>
              )}

              {/* Prediction Market Mode: Multi-Outcome Builder */}
              {betMode === 'prediction-market' && (
                <div className="space-y-4">
                  {/* Multi-Outcome Builder */}
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <Label className="text-white">Market Outcomes</Label>
                      <span className="text-xs text-blue-200/60">Min 2, Max 5</span>
                    </div>
                    
                    {/* Outcome Rows */}
                    <div className="space-y-2">
                      {marketOutcomes.map((outcome, index) => (
                        <div 
                          key={outcome.id} 
                          className="bg-white/5 border border-blue-400/20 rounded-lg p-3 space-y-2"
                        >
                          {/* Row Header with Drag Handle and Delete */}
                          <div className="flex items-center gap-2">
                            <div className="flex flex-col gap-1">
                              <button
                                onClick={() => moveMarketOutcome(index, 'up')}
                                disabled={index === 0}
                                className="text-blue-400/40 hover:text-blue-400 disabled:opacity-30 disabled:cursor-not-allowed"
                              >
                                <GripVertical className="h-3 w-3" />
                              </button>
                              <button
                                onClick={() => moveMarketOutcome(index, 'down')}
                                disabled={index === marketOutcomes.length - 1}
                                className="text-blue-400/40 hover:text-blue-400 disabled:opacity-30 disabled:cursor-not-allowed"
                              >
                                <GripVertical className="h-3 w-3" />
                              </button>
                            </div>
                            
                            <div className="flex-1 grid grid-cols-2 gap-2">
                              <Input
                                placeholder={`Outcome ${index + 1}`}
                                value={outcome.name}
                                onChange={(e) => updateMarketOutcomeName(outcome.id, e.target.value)}
                                className="bg-white/5 border-blue-400/30 text-white placeholder:text-white/40"
                              />
                              <div className="relative">
                                <Input
                                  type="text"
                                  placeholder="50.0"
                                  value={outcome.startPct}
                                  onChange={(e) => updateMarketOutcomePct(outcome.id, e.target.value)}
                                  className="bg-white/5 border-blue-400/30 text-white placeholder:text-white/40 pr-16"
                                />
                                <Badge 
                                  className="absolute right-2 top-1/2 -translate-y-1/2 bg-blue-500/20 text-blue-300 border-blue-400/30 pointer-events-none"
                                >
                                  {outcome.startPct || '0'}%
                                </Badge>
                              </div>
                            </div>
                            
                            <Button
                              variant="outline"
                              size="icon"
                              onClick={() => removeMarketOutcome(outcome.id)}
                              disabled={marketOutcomes.length <= 2}
                              className="border-red-400/30 text-red-400 hover:bg-red-500/10 disabled:opacity-30 disabled:cursor-not-allowed shrink-0"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                          
                          {/* Even Split Helper */}
                          <button
                            onClick={() => {
                              const evenShare = (100 / marketOutcomes.length).toFixed(1);
                              updateMarketOutcomePct(outcome.id, evenShare);
                            }}
                            className="text-xs text-blue-400 hover:text-blue-300 transition-colors"
                          >
                            Set to even split ({(100 / marketOutcomes.length).toFixed(1)}%)
                          </button>
                        </div>
                      ))}
                    </div>
                    
                    {/* Add Outcome & Auto-Distribute Buttons */}
                    <div className="flex gap-2">
                      {marketOutcomes.length < 5 && (
                        <Button
                          variant="outline"
                          onClick={addMarketOutcome}
                          className="flex-1 border-blue-400/30 text-blue-300 hover:bg-blue-500/10"
                        >
                          <Plus className="h-4 w-4 mr-2" />
                          Add Outcome
                        </Button>
                      )}
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          autoDistributePercentages();
                          setHasManuallyEditedPct(false);
                        }}
                        className="text-blue-300 hover:bg-blue-500/10"
                      >
                        Auto-Distribute
                      </Button>
                    </div>
                    
                    {/* Total Meter */}
                    <div className="bg-white/5 border border-blue-400/20 rounded-lg p-3 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-blue-200">Total:</span>
                        <span className={`text-sm ${
                          Math.abs(calculateTotalPct() - 100) < 0.01 
                            ? 'text-green-400' 
                            : 'text-red-400'
                        }`}>
                          {calculateTotalPct().toFixed(1)}% / 100%
                        </span>
                      </div>
                      
                      {/* Progress Bar */}
                      <div className="w-full h-2 bg-white/10 rounded-full overflow-hidden">
                        <div 
                          className={`h-full transition-all ${
                            Math.abs(calculateTotalPct() - 100) < 0.01
                              ? 'bg-green-500'
                              : calculateTotalPct() > 100
                              ? 'bg-red-500'
                              : 'bg-yellow-500'
                          }`}
                          style={{ width: `${Math.min(calculateTotalPct(), 100)}%` }}
                        />
                      </div>
                      
                      {/* Validation Helper */}
                      {Math.abs(calculateTotalPct() - 100) > 0.01 && (
                        <div className="text-xs text-red-400">
                          ⚠️ Adjust percentages — total must equal 100%
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Creator Fee */}
                  <div className="space-y-3">
                    <Label className="text-white">Creator Fee: {creatorFee}%</Label>
                    <p className="text-xs text-blue-200/60 -mt-1">
                      Fee you earn from each trade (0-7%)
                    </p>
                    <Slider
                      value={[creatorFee]}
                      onValueChange={(value) => setCreatorFee(value[0])}
                      min={0}
                      max={7}
                      step={0.5}
                      className="w-full"
                    />
                    <div className="flex justify-between text-xs text-blue-200/50">
                      <span>0% (Free)</span>
                      <span>7% Max</span>
                    </div>
                  </div>

                  {/* Event Date */}
                  <div className="space-y-2">
                    <Label htmlFor="eventDate" className="text-white">
                      Event Date
                    </Label>
                    <Input
                      id="eventDate"
                      type="datetime-local"
                      value={eventDate}
                      onChange={(e) => setEventDate(e.target.value)}
                      className="bg-white/5 border-blue-400/30 text-white"
                    />
                  </div>

                  {/* Trading Deadline */}
                  <div className="space-y-2">
                    <Label htmlFor="tradingDeadline" className="text-white">
                      Trading Deadline
                    </Label>
                    <Input
                      id="tradingDeadline"
                      type="datetime-local"
                      value={tradingDeadline}
                      onChange={(e) => setTradingDeadline(e.target.value)}
                      className="bg-white/5 border-blue-400/30 text-white"
                    />
                    <p className="text-xs text-blue-200/60">
                      Trading will be locked at this time
                    </p>
                  </div>
                </div>
              )}

              {/* Outcomes - Book Mode Only */}
              {betMode === 'book' && (
                <div className="space-y-3">
                  <Label className="text-white">Add Outcomes</Label>
                  {outcomes.map((outcome, index) => (
                    <div key={outcome.id} className="flex gap-2">
                      <Input
                        placeholder={`Outcome ${String.fromCharCode(65 + index)} (e.g., Team A)`}
                        value={outcome.name}
                        onChange={(e) => updateOutcomeName(outcome.id, e.target.value)}
                        className="bg-white/5 border-blue-400/30 text-white placeholder:text-white/40"
                      />
                      {outcomes.length > 2 && (
                        <Button
                          variant="outline"
                          size="icon"
                          onClick={() => removeOutcome(outcome.id)}
                          className="border-red-400/30 text-red-400 hover:bg-red-500/10"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                  ))}
                  {outcomes.length < 5 && (
                    <Button
                      variant="outline"
                      onClick={addOutcome}
                      className="w-full border-blue-400/30 text-blue-300 hover:bg-blue-500/10"
                    >
                      <Plus className="h-4 w-4 mr-2" />
                      Add Another Outcome
                    </Button>
                  )}
                </div>
              )}

              {/* Next Button */}
              <Button
                onClick={betMode === 'book' ? goToStep2 : goToStep3}
                className="w-full bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white border-0 h-12"
              >
                {betMode === 'book' ? 'Next: Set Odds →' : 'Next: Preview Market →'}
              </Button>
            </>
          )}

          {/* Step 2: Smart Odds Assistant */}
          {step === 2 && outcomes.length === 2 && (
            <>
              {/* Probability Slider */}
              <div className="space-y-4">
                <Label className="text-white">Who's more likely to win?</Label>
                <div className="bg-white/5 border border-blue-400/20 rounded-xl p-6 space-y-6">
                  {/* Slider */}
                  <div className="space-y-4">
                    <div className="flex justify-between text-sm">
                      <span className="text-blue-300">{outcomes[0].name || 'Outcome A'}</span>
                      <span className="text-purple-300">{outcomes[1].name || 'Outcome B'}</span>
                    </div>
                    <Slider
                      value={[probabilitySlider]}
                      onValueChange={handleSliderChange}
                      min={5}
                      max={95}
                      step={5}
                      className="w-full"
                    />
                    <div className="flex justify-between text-xs text-blue-200/50">
                      <span>{usingCustomProb ? parseFloat(customProbA || '0').toFixed(1) : probabilitySlider}%</span>
                      <span>50% = Even</span>
                      <span>{usingCustomProb ? parseFloat(customProbB || '0').toFixed(1) : 100 - probabilitySlider}%</span>
                    </div>
                  </div>

                  {/* Custom Percentage Inputs */}
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <Label className="text-sm text-blue-200">Manual Input</Label>
                      {usingCustomProb && (
                        <span className="text-xs text-blue-400">✓ Active</span>
                      )}
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <Label className="text-xs text-blue-200/70">{outcomes[0].name || 'Outcome A'}</Label>
                        <div className="relative">
                          <Input
                            type="text"
                            value={customProbA}
                            onChange={(e) => handleCustomProbAChange(e.target.value)}
                            className="bg-white/5 border-blue-400/30 text-white pr-8"
                            placeholder="50"
                          />
                          <span className="absolute right-3 top-1/2 -translate-y-1/2 text-blue-300 text-sm">%</span>
                        </div>
                      </div>
                      <div className="space-y-1">
                        <Label className="text-xs text-blue-200/70">{outcomes[1].name || 'Outcome B'}</Label>
                        <div className="relative">
                          <Input
                            type="text"
                            value={customProbB}
                            onChange={(e) => handleCustomProbBChange(e.target.value)}
                            className="bg-white/5 border-blue-400/30 text-white pr-8"
                            placeholder="50"
                          />
                          <span className="absolute right-3 top-1/2 -translate-y-1/2 text-purple-300 text-sm">%</span>
                        </div>
                      </div>
                    </div>
                    
                    {/* Helper Text */}
                    <div className="space-y-1">
                      <div className={`text-xs ${customProbsValid() ? 'text-blue-200/60' : 'text-red-400'}`}>
                        {customProbsValid() ? '✓ Totals must equal 100%.' : '⚠️ Totals must equal 100%.'}
                      </div>
                      <div className="text-xs text-blue-200/50">
                        You can move the slider or type custom values — both update live.
                      </div>
                    </div>
                  </div>

                  {/* Auto-generated odds */}
                  <div className="space-y-3">
                    <div className="flex items-center gap-2">
                      <span className="text-sm text-blue-200">Auto-generated odds:</span>
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Info className="h-4 w-4 text-blue-400 cursor-help" />
                          </TooltipTrigger>
                          <TooltipContent className="bg-slate-800 border-blue-400/30 text-white max-w-xs">
                            <p className="text-sm">
                              {houseEdge}% house edge applied automatically to ensure sustainable book management
                            </p>
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      {oddsPreview.map((outcome, index) => (
                        <div
                          key={outcome.id}
                          className={`bg-gradient-to-br ${
                            index === 0
                              ? 'from-blue-500/20 to-blue-600/10 border-blue-400/30'
                              : 'from-purple-500/20 to-purple-600/10 border-purple-400/30'
                          } border rounded-lg p-4`}
                        >
                          <div className="text-sm text-white/70 mb-1">{outcome.name}</div>
                          <div className="text-2xl text-white">{outcome.odds.toFixed(2)}x</div>
                          {outcome.odds <= 1.5 && <div className="text-xs text-white/50 mt-1">🔥 Favored</div>}
                          {outcome.odds >= 2.5 && <div className="text-xs text-white/50 mt-1">🧊 Underdog</div>}
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Warning for extreme odds */}
                  {(probabilitySlider >= 90 || probabilitySlider <= 10) && (
                    <div className="bg-yellow-500/10 border border-yellow-400/30 rounded-lg p-3">
                      <div className="text-xs text-yellow-300">
                        ⚠️ Low payout because this side is almost guaranteed
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Advanced Settings Toggle */}
              <div className="space-y-3">
                <Button
                  variant="ghost"
                  onClick={() => setShowAdvancedSettings(!showAdvancedSettings)}
                  className="w-full text-blue-300 hover:bg-white/5 flex items-center justify-between"
                >
                  <span>⚙️ Advanced Settings</span>
                  <span className="text-xs">{showAdvancedSettings ? '▼' : '▶'}</span>
                </Button>

                {showAdvancedSettings && (
                  <div className="bg-white/5 border border-blue-400/20 rounded-xl p-4 space-y-4">
                    {/* House Edge Control */}
                    <div className="space-y-3">
                      <div>
                        <Label className="text-white">House Edge: {houseEdge}%</Label>
                        <p className="text-xs text-blue-200/70 mt-1">
                          Choose your book's profit margin. Minimum 3%, Maximum 10%.
                        </p>
                      </div>
                      
                      <Slider
                        value={[houseEdge]}
                        onValueChange={(value) => setHouseEdge(Math.max(3, Math.min(10, value[0])))}
                        min={3}
                        max={10}
                        step={1}
                        className="w-full"
                      />

                      <div className="flex justify-between text-xs text-blue-200/50">
                        <span>3% Min</span>
                        <span>7% Default</span>
                        <span>10% Max</span>
                      </div>

                      <div className="bg-blue-500/10 border border-blue-400/20 rounded-lg p-3">
                        <div className="text-xs text-blue-200/70 mb-1">
                          House edge is automatically applied to your odds.
                        </div>
                        <div className="text-sm text-white">
                          Estimated Profit: +{Math.round(1000 * (houseEdge / 100))} chips per 1,000 wagered
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Next Button */}
              <Button
                onClick={goToStep3}
                className="w-full bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white border-0 h-12"
              >
                Next: Preview Bet →
              </Button>
            </>
          )}

          {/* Step 2: Multiple outcomes (simplified) */}
          {step === 2 && outcomes.length > 2 && (
            <>
              <div className="bg-yellow-500/10 border border-yellow-400/30 rounded-lg p-4">
                <div className="text-sm text-yellow-300">
                  ℹ️ Multiple outcomes detected. Please set custom odds for each outcome.
                </div>
              </div>

              <div className="space-y-3">
                <Label className="text-white">Set Odds for Each Outcome</Label>
                {outcomes.map((outcome) => (
                  <div key={outcome.id} className="space-y-2">
                    <Label className="text-sm text-blue-200">{outcome.name}</Label>
                    <Input
                      type="number"
                      step="0.1"
                      placeholder="2.0"
                      value={customOdds[outcome.id] || ''}
                      onChange={(e) => setCustomOdds({ ...customOdds, [outcome.id]: e.target.value })}
                      className="bg-white/5 border-blue-400/30 text-white placeholder:text-white/40"
                    />
                  </div>
                ))}
              </div>

              <Button
                onClick={goToStep3}
                className="w-full bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white border-0 h-12"
              >
                Next: Preview Bet →
              </Button>
            </>
          )}

          {/* Step 3: Preview */}
          {step === 3 && betMode === 'book' && (
            <>
              {/* Bet Summary Card */}
              <div className="bg-gradient-to-br from-blue-500/10 to-purple-500/10 border border-blue-400/30 rounded-xl p-6 space-y-4">
                <h2 className="text-xl text-white">{title}</h2>
                <div className="text-sm text-blue-200">{category} Bet</div>

                {/* Bet Range */}
                <div className="bg-white/5 rounded-lg p-3">
                  <div className="text-xs text-blue-200/70 mb-1">Bet Range</div>
                  <div className="text-white">
                    Players can wager between {minBet} – {maxBet} chips
                  </div>
                </div>

                {/* Outcomes & Odds */}
                <div className="space-y-2">
                  <div className="text-xs text-blue-200/70">Current Odds</div>
                  <div className="grid gap-2">
                    {(useRecommendedOdds && outcomes.length === 2 ? oddsPreview : outcomes.map((o) => ({
                      ...o,
                      odds: parseFloat(customOdds[o.id] || '2.0'),
                    }))).map((outcome) => (
                      <div
                        key={outcome.id}
                        className="flex justify-between items-center bg-white/5 rounded-lg p-3"
                      >
                        <span className="text-white">{outcome.name}</span>
                        <span className="text-blue-300">{outcome.odds.toFixed(2)}x</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* House Edge */}
                {useRecommendedOdds && (
                  <div className="bg-green-500/10 border border-green-400/30 rounded-lg p-3">
                    <div className="text-xs text-green-300 mb-1">House Edge</div>
                    <div className="text-white">{houseEdge}% (auto-applied)</div>
                  </div>
                )}

                {/* Estimated Profit */}
                {useRecommendedOdds && (
                  <div className="bg-blue-500/10 border border-blue-400/30 rounded-lg p-3">
                    <div className="text-xs text-blue-200/70 mb-1">Estimated Book Profit</div>
                    <div className="text-white">
                      ~+{calculateEstimatedProfit()} chips per 1,000 wagered
                    </div>
                  </div>
                )}

                {/* Auto-rebalance */}
                <div className="flex items-center justify-between bg-white/5 rounded-lg p-3">
                  <div>
                    <div className="text-sm text-white">Auto-Rebalance</div>
                    <div className="text-xs text-blue-200/70">
                      Odds adjust automatically as players join
                    </div>
                  </div>
                  <Switch checked={autoRebalance} onCheckedChange={setAutoRebalance} />
                </div>
              </div>

              {/* Info Note */}
              <div className="bg-blue-500/10 border border-blue-400/30 rounded-lg p-4">
                <div className="text-xs text-blue-200">
                  💡 Odds may slightly adjust as more players join to keep things balanced.
                </div>
              </div>

              {/* Publish Button */}
              <Button
                onClick={publishBet}
                className="w-full bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white border-0 h-12 shadow-lg shadow-green-500/20"
              >
                🟢 Publish Bet
              </Button>

              {/* Back to adjust settings */}
              <Button
                variant="ghost"
                className="w-full text-blue-300 hover:bg-white/5"
                onClick={() => setStep(2)}
              >
                ← Back to Adjust Odds
              </Button>
            </>
          )}

          {/* Step 3: Preview Market (Prediction Market Mode) */}
          {step === 3 && betMode === 'prediction-market' && (
            <>
              {/* Market Summary Card */}
              <div className="bg-gradient-to-br from-blue-500/10 to-purple-500/10 border border-blue-400/30 rounded-xl p-6 space-y-4">
                <h2 className="text-xl text-white">{title}</h2>
                <div className="text-sm text-blue-200">{category} · Prediction Market</div>

                {/* Multi-Outcome Pills */}
                <div className="space-y-2">
                  <div className="text-xs text-blue-200/70">Starting Market Prices</div>
                  <div className="flex flex-wrap gap-2">
                    {marketOutcomes.map((outcome) => (
                      <Badge 
                        key={outcome.id}
                        className="bg-gradient-to-r from-blue-500/20 to-purple-500/20 text-white border-blue-400/30 px-3 py-1"
                      >
                        {outcome.name}: {outcome.startPct}%
                      </Badge>
                    ))}
                  </div>
                  
                  {/* Visual Price Bar */}
                  <div className="flex rounded-lg overflow-hidden h-12">
                    {marketOutcomes.map((outcome, index) => {
                      const colors = [
                        'bg-blue-500/80',
                        'bg-purple-500/80',
                        'bg-green-500/80',
                        'bg-orange-500/80',
                        'bg-pink-500/80',
                      ];
                      return (
                        <div 
                          key={outcome.id}
                          className={`${colors[index % colors.length]} flex items-center justify-center text-white transition-all`}
                          style={{ width: `${outcome.startPct}%` }}
                        >
                          {parseFloat(outcome.startPct) >= 15 && (
                            <span className="text-xs px-1 text-center">
                              {outcome.name.length > 12 ? outcome.name.substring(0, 12) + '...' : outcome.name} {outcome.startPct}%
                            </span>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Creator Fee */}
                <div className="bg-white/5 rounded-lg p-3">
                  <div className="text-xs text-blue-200/70 mb-1">Creator Fee</div>
                  <div className="text-white">{creatorFee}% per trade</div>
                </div>

                {/* Event Date */}
                {eventDate && (
                  <div className="bg-white/5 rounded-lg p-3">
                    <div className="text-xs text-blue-200/70 mb-1">Event Date</div>
                    <div className="text-white">
                      {new Date(eventDate).toLocaleString('en-US', {
                        month: 'short',
                        day: 'numeric',
                        year: 'numeric',
                        hour: 'numeric',
                        minute: '2-digit',
                      })}
                    </div>
                  </div>
                )}

                {/* Trading Deadline */}
                {tradingDeadline && (
                  <div className="bg-orange-500/10 border border-orange-400/30 rounded-lg p-3">
                    <div className="text-xs text-orange-300 mb-1">Trading Closes</div>
                    <div className="text-white">
                      {new Date(tradingDeadline).toLocaleString('en-US', {
                        month: 'short',
                        day: 'numeric',
                        year: 'numeric',
                        hour: 'numeric',
                        minute: '2-digit',
                      })}
                    </div>
                  </div>
                )}

                {/* Live Trading Preview */}
                <div className="bg-blue-500/10 border border-blue-400/30 rounded-lg p-4">
                  <div className="text-xs text-blue-200 mb-2">📊 How It Works</div>
                  <div className="text-xs text-blue-200/70">
                    Players can buy/sell shares for any outcome. Prices adjust based on demand. Market resolves when event occurs.
                  </div>
                </div>
              </div>

              {/* Info Note */}
              <div className="bg-purple-500/10 border border-purple-400/30 rounded-lg p-4">
                <div className="text-xs text-purple-200">
                  🎯 Prediction markets let players trade shares like stocks. Prices reflect crowd wisdom!
                </div>
              </div>

              {/* Create Market Button */}
              <Button
                onClick={publishBet}
                className="w-full bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white border-0 h-12 shadow-lg shadow-green-500/20"
              >
                🟢 Create Market
              </Button>

              {/* Back to edit */}
              <Button
                variant="ghost"
                className="w-full text-blue-300 hover:bg-white/5"
                onClick={() => setStep(1)}
              >
                ← Back to Edit Details
              </Button>
            </>
          )}
        </div>
      </ScrollArea>
    </div>
  );
}