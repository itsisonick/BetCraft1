import { Label } from './ui/label';
import { ArrowLeft, Coins, TrendingUp, Info } from 'lucide-react';
import { toast } from 'sonner';
import { ScrollArea } from './ui/scroll-area';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from './ui/tooltip';

interface BetDetailsScreenProps {
  bet: Bet;
  userRedChips: number;
  isOwner: boolean;
  onNavigateBack: () => void;
  onPlaceBet: (betId: number, outcomeId: string, amount: number) => boolean;
}

export default function BetDetailsScreen({ 
  bet, 
  userRedChips,
  isOwner,
  onNavigateBack, 
  onPlaceBet 
}: BetDetailsScreenProps) {
  const [selectedOutcomeId, setSelectedOutcomeId] = useState<string | null>(null);
  const [betAmount, setBetAmount] = useState('');

  const totalChips = bet.outcomes.reduce((sum, outcome) => sum + outcome.totalChips, 0);

  const handlePlaceBet = () => {
    if (!selectedOutcomeId) {
      toast.error('Please select an outcome');
      return;
    }
    
    const amount = parseInt(betAmount);
    if (!amount || amount <= 0) {
      toast.error('Please enter a valid bet amount');
      return;
    }

    if (amount < bet.minBet) {
      toast.error(`Minimum bet is ${bet.minBet} chips`);
      return;
    }

    if (amount > bet.maxBet) {
      toast.error(`Maximum bet is ${bet.maxBet} chips`);
      return;
    }

    if (amount > userRedChips) {
      toast.error('Not enough chips');
      return;
    }

    const success = onPlaceBet(bet.id, selectedOutcomeId, amount);
    if (success) {
      const outcome = bet.outcomes.find(o => o.id === selectedOutcomeId);
      toast.success(`Placed ${amount} chips on ${outcome?.name}!`);
      setSelectedOutcomeId(null);
      setBetAmount('');
    } else {
      toast.error('Failed to place bet');
    }
  };

  const selectedOutcome = bet.outcomes.find(o => o.id === selectedOutcomeId);
  const potentialWin = selectedOutcome && betAmount ? Math.floor(parseInt(betAmount) * selectedOutcome.odds) : 0;

  return (
    <div className="min-h-screen flex flex-col text-white" style={{
      background: 'linear-gradient(to bottom, #05122B 0%, #0C1B35 100%)'
    }}>
      {/* Header */}
      <div className="p-6 pb-8 bg-gradient-to-r from-blue-600/20 to-purple-600/20 border-b border-blue-400/20">
        <div className="flex items-center justify-between mb-6">
          <Button
            variant="ghost"
            size="icon"
            onClick={onNavigateBack}
            className="text-white hover:bg-white/10"
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          {isOwner && (
            <div className="text-xs bg-blue-500/20 px-3 py-1 rounded-full border border-blue-400/30">
              Owner
            </div>
          )}
        </div>
        <h1 className="text-2xl mb-2">{bet.title}</h1>
        <p className="text-sm text-blue-200/70">{bet.description}</p>
        
        {/* Bet Range */}
        <div className="mt-4 flex items-center gap-2 text-sm text-red-300">
          <span className="text-base">🔴</span>
          <span>Bet Range: {bet.minBet} - {bet.maxBet} chips</span>
        </div>
      </div>

      <ScrollArea className="flex-1">
        <div className="p-6 space-y-6 pb-24">
          {/* Total Pool */}
          {totalChips > 0 && (
            <Card className="p-5 bg-gradient-to-br from-red-500/10 to-red-600/10 border border-red-400/30">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-red-200">Total Pool</span>
                <span className="flex items-center gap-1 text-white">
                  <span className="text-base">🔴</span>
                  {totalChips.toLocaleString()} chips
                </span>
              </div>
            </Card>
          )}

          {/* Outcomes */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Label className="text-white">Select Your Pick</Label>
              {bet.houseEdge > 0 && (
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <div className="flex items-center gap-1 text-xs text-green-400 cursor-help">
                        <Info className="h-3 w-3" />
                        {bet.houseEdge}% edge
                      </div>
                    </TooltipTrigger>
                    <TooltipContent className="bg-slate-800 border-blue-400/30 text-white max-w-xs">
                      <p className="text-sm">
                        Book maintains a {bet.houseEdge}% edge for sustainable management
                      </p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              )}
            </div>

            {bet.outcomes.map((outcome, index) => {
              const percentage = totalChips > 0 ? (outcome.totalChips / totalChips) * 100 : 0;
              const isFavored = outcome.odds < 2.0;
              const isUnderdog = outcome.odds >= 2.5;
              
              return (
                <Card
                  key={outcome.id}
                  className={`p-5 cursor-pointer transition-all ${
                    selectedOutcomeId === outcome.id
                      ? 'bg-gradient-to-br from-blue-500/30 to-blue-600/20 border-blue-400 shadow-lg shadow-blue-500/20'
                      : 'bg-white/5 border-blue-400/30 hover:border-blue-400/50 hover:bg-white/10'
                  }`}
                  onClick={() => setSelectedOutcomeId(outcome.id)}
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="text-white">{outcome.name}</h3>
                        {isFavored && <span className="text-xs">🔥</span>}
                        {isUnderdog && <span className="text-xs">🧊</span>}
                      </div>
                      <div className="flex items-center gap-1">
                        <TrendingUp className="h-4 w-4 text-yellow-400" />
                        <span className="text-yellow-400">{outcome.odds.toFixed(2)}x</span>
                        {isFavored && <span className="text-xs text-yellow-300/70 ml-1">Favored</span>}
                        {isUnderdog && <span className="text-xs text-blue-300/70 ml-1">Underdog</span>}
                      </div>
                    </div>
                    {selectedOutcomeId === outcome.id && (
                      <div className="bg-blue-500 rounded-full h-6 w-6 flex items-center justify-center">
                        <div className="text-white text-xs">✓</div>
                      </div>
                    )}
                  </div>

                  {/* Live Stats */}
                  {outcome.users > 0 && (
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-xs text-blue-200/70">
                        <span>{outcome.users} player{outcome.users !== 1 ? 's' : ''}</span>
                        <span>{outcome.totalChips.toLocaleString()} chips</span>
                      </div>
                      {totalChips > 0 && (
                        <div className="space-y-1">
                          <Progress value={percentage} className="h-1.5" />
                          <div className="text-xs text-blue-200/70">{percentage.toFixed(1)}% of pool</div>
                        </div>
                      )}
                    </div>
                  )}
                </Card>
              );
            })}
          </div>

          {/* Bet Amount Input */}
          {selectedOutcomeId && (
            <div className="bg-gradient-to-br from-red-500/10 to-red-600/10 border border-red-400/30 rounded-xl p-6 space-y-4">
              <Label htmlFor="betAmount" className="text-white flex items-center gap-2">
                <span className="text-base">🔴</span>
                Enter Bet Amount (Red Chips)
              </Label>
              <Input
                id="betAmount"
                type="number"
                placeholder="Enter amount"
                value={betAmount}
                onChange={(e) => setBetAmount(e.target.value)}
                className="bg-white/5 border-red-400/30 text-white placeholder:text-white/40 text-lg h-14"
              />
              <div className="flex items-center justify-between text-sm">
                <span className="text-red-200/70">Min: {bet.minBet} 🔴</span>
                <span className="text-red-200/70">Max: {bet.maxBet} 🔴</span>
              </div>

              {/* Quick Amount Buttons */}
              <div className="grid grid-cols-4 gap-2">
                {[bet.minBet, bet.minBet * 2, bet.minBet * 5, bet.maxBet].map((amount) => (
                  <Button
                    key={amount}
                    variant="outline"
                    size="sm"
                    onClick={() => setBetAmount(amount.toString())}
                    className="bg-white/5 border-red-400/30 text-red-200 hover:bg-red-500/20 hover:border-red-400"
                  >
                    {amount}
                  </Button>
                ))}
              </div>

              {/* Potential Win */}
              {potentialWin > 0 && (
                <div className="bg-green-500/10 border border-green-400/30 rounded-lg p-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-green-300">Potential Win</span>
                    <span className="text-lg text-white flex items-center gap-1">
                      🔴 {potentialWin.toLocaleString()} chips
                    </span>
                  </div>
                  <div className="text-xs text-green-300/70 mt-1">
                    Profit: +{(potentialWin - parseInt(betAmount)).toLocaleString()} chips
                  </div>
                </div>
              )}

              {/* Place Bet Button */}
              <Button
                onClick={handlePlaceBet}
                disabled={!betAmount || parseInt(betAmount) <= 0}
                className="w-full bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white border-0 h-12 disabled:from-gray-500 disabled:to-gray-600"
              >
                Confirm Bet
              </Button>
            </div>
          )}

          {/* Owner Controls */}
          {isOwner && (
            <div className="bg-purple-500/10 border border-purple-400/30 rounded-xl p-6 space-y-4">
              <h3 className="text-white">Owner Controls</h3>
              
              {/* Chip Exposure */}
              <div className="space-y-2">
                <div className="text-sm text-purple-200/70">Chip Exposure Tracker</div>
                {bet.outcomes.map((outcome) => (
                  <div key={outcome.id} className="flex items-center justify-between text-sm">
                    <span className="text-white">{outcome.name}</span>
                    <span className="text-purple-300">
                      {outcome.users} bets • {outcome.totalChips.toLocaleString()} chips
                    </span>
                  </div>
                ))}
              </div>

              {/* Actions */}
              <div className="grid grid-cols-2 gap-3 pt-2">
                <Button
                  variant="outline"
                  className="border-green-400/30 text-green-300 hover:bg-green-500/10"
                  onClick={() => toast.info('Claim profit coming soon!')}
                >
                  End Bet & Claim
                </Button>
                <Button
                  variant="outline"
                  className="border-red-400/30 text-red-300 hover:bg-red-500/10"
                  onClick={() => toast.info('Refund all coming soon!')}
                >
                  Refund All
                </Button>
              </div>
            </div>
          )}

          {/* Your Chips */}
          <div className="bg-white/5 border border-blue-400/20 rounded-lg p-4">
            <div className="flex items-center justify-between text-sm">
              <span className="text-blue-200/70">Your Available Chips</span>
              <span className="flex items-center gap-1 text-white">
                <Coins className="h-4 w-4 text-red-400" />
                {userRedChips.toLocaleString()}
              </span>
            </div>
          </div>
        </div>
      </ScrollArea>
    </div>
  );
}