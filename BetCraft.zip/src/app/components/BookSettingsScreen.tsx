import { ArrowLeft, Save, Upload, Trash2 } from 'lucide-react';
import { ScrollArea } from './ui/scroll-area';
import { toast } from 'sonner';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from './ui/alert-dialog';

interface BookSettingsScreenProps {
  book: Book;
  isOwner: boolean;
  onNavigateBack: () => void;
  onSaveSettings: (settings: BookSettings) => void;
  onDeleteBook: () => void;
}

export interface BookSettings {
  name: string;
  logo: string;
  themeColor: 'blue' | 'purple' | 'green' | 'red';
  pinnedMessage: string;
  enableLeaderboard: boolean;
  enableUnion: boolean;
  defaultHouseEdge: number;
}

const defaultEmojis = ['🏀', '🎬', '💻', '🎮', '⚽', '🎯', '🎲', '🏈', '⚾', '🎾', '🏐', '🎱', '🎳', '🥊', '🏆'];

const themeColors = {
  blue: { name: 'BetCraft Blue', gradient: 'from-blue-500 to-purple-600' },
  purple: { name: 'Royal Purple', gradient: 'from-purple-500 to-pink-600' },
  green: { name: 'Emerald Green', gradient: 'from-emerald-500 to-teal-600' },
  red: { name: 'Crimson Red', gradient: 'from-red-500 to-orange-600' },
};

export default function BookSettingsScreen({ book, isOwner, onNavigateBack, onSaveSettings, onDeleteBook }: BookSettingsScreenProps) {
  const [bookName, setBookName] = useState(book.name);
  const [selectedLogo, setSelectedLogo] = useState(book.logo);
  const [themeColor, setThemeColor] = useState<'blue' | 'purple' | 'green' | 'red'>('blue');
  const [pinnedMessage, setPinnedMessage] = useState(`💬 Message @${book.ownerName} for chips`);
  const [enableLeaderboard, setEnableLeaderboard] = useState(false);
  const [enableUnion, setEnableUnion] = useState(false);
  const [defaultHouseEdge, setDefaultHouseEdge] = useState(book.defaultHouseEdge || 7);

  const handleSave = () => {
    onSaveSettings({
      name: bookName,
      logo: selectedLogo,
      themeColor,
      pinnedMessage,
      enableLeaderboard,
      enableUnion,
      defaultHouseEdge,
    });
    toast.success('Settings saved successfully');
    onNavigateBack();
  };

  return (
    <div className="min-h-screen flex flex-col text-white" style={{
      background: 'linear-gradient(to bottom, #05122B 0%, #0C1B35 100%)'
    }}>
      {/* Header */}
      <div className="sticky top-0 z-30 backdrop-blur-lg border-b border-white/10" style={{
        background: 'rgba(5, 18, 43, 0.8)'
      }}>
        <div className="p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="icon"
              onClick={onNavigateBack}
              className="text-white hover:bg-white/10 rounded-full h-9 w-9"
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <h1 className="text-xl">Book Settings</h1>
          </div>
          <Button
            onClick={handleSave}
            className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 border-0 h-9"
          >
            <Save className="h-4 w-4 mr-2" />
            Save
          </Button>
        </div>
      </div>

      {/* Content */}
      <ScrollArea className="flex-1">
        <div className="p-6 space-y-6 max-w-md mx-auto">
          {/* Basic Info */}
          <div className="space-y-4">
            <h2 className="text-lg text-blue-300">Basic Information</h2>
            
            <div className="space-y-2">
              <Label htmlFor="bookName" className="text-blue-200">Book Name</Label>
              <Input
                id="bookName"
                type="text"
                value={bookName}
                onChange={(e) => setBookName(e.target.value)}
                className="bg-white/5 border-blue-400/30 text-white"
                maxLength={30}
              />
            </div>

            <div className="space-y-2">
              <Label className="text-blue-200">Book Logo</Label>
              <div className="grid grid-cols-5 gap-2">
                {defaultEmojis.map((emoji) => (
                  <button
                    key={emoji}
                    onClick={() => setSelectedLogo(emoji)}
                    className={`aspect-square rounded-xl flex items-center justify-center text-3xl transition-all ${
                      selectedLogo === emoji
                        ? 'bg-gradient-to-br from-blue-500 to-purple-600 shadow-lg shadow-blue-500/30'
                        : 'bg-white/5 hover:bg-white/10 border border-blue-400/20'
                    }`}
                  >
                    {emoji}
                  </button>
                ))}
              </div>
            </div>

            <div className="bg-white/5 border border-blue-400/30 rounded-xl p-3">
              <p className="text-xs text-blue-300/70 mb-1">Book Code</p>
              <p className="text-lg" style={{
                background: 'linear-gradient(135deg, #1A73E8 0%, #8B5CF6 100%)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                fontWeight: 'bold'
              }}>
                #{book.bookId}
              </p>
            </div>
          </div>

          {/* Theme Colors */}
          <div className="space-y-4">
            <h2 className="text-lg text-blue-300">Theme Color</h2>
            <div className="grid grid-cols-2 gap-3">
              {(Object.keys(themeColors) as Array<keyof typeof themeColors>).map((color) => (
                <button
                  key={color}
                  onClick={() => setThemeColor(color)}
                  className={`p-4 rounded-xl border transition-all ${
                    themeColor === color
                      ? 'border-white/60 shadow-lg'
                      : 'border-blue-400/20 hover:border-blue-400/40'
                  }`}
                >
                  <div className={`h-12 rounded-lg bg-gradient-to-r ${themeColors[color].gradient} mb-2`}></div>
                  <p className="text-sm">{themeColors[color].name}</p>
                </button>
              ))}
            </div>
          </div>

          {/* Pinned Message */}
          <div className="space-y-4">
            <h2 className="text-lg text-blue-300">Pinned Message</h2>
            <div className="space-y-2">
              <Label htmlFor="pinnedMessage" className="text-blue-200">Custom Message</Label>
              <Textarea
                id="pinnedMessage"
                value={pinnedMessage}
                onChange={(e) => setPinnedMessage(e.target.value)}
                className="bg-white/5 border-blue-400/30 text-white resize-none"
                rows={3}
                maxLength={150}
                placeholder="e.g., Message @Owner for chips"
              />
              <p className="text-xs text-blue-300/50">{pinnedMessage.length}/150 characters</p>
            </div>
            <div className="bg-blue-500/10 border border-blue-400/30 rounded-lg p-3">
              <p className="text-sm text-blue-200">{pinnedMessage}</p>
            </div>
          </div>

          {/* Banner Upload (Placeholder) */}
          <div className="space-y-4">
            <h2 className="text-lg text-blue-300">Banner Image</h2>
            <button className="w-full aspect-[3/1] bg-white/5 border-2 border-dashed border-blue-400/30 rounded-xl flex flex-col items-center justify-center hover:bg-white/10 transition-all">
              <Upload className="h-8 w-8 text-blue-400 mb-2" />
              <p className="text-sm text-blue-300">Upload Banner (16:9)</p>
              <p className="text-xs text-blue-300/50 mt-1">Coming soon</p>
            </button>
          </div>

          {/* House Edge Settings - Owner Only */}
          {isOwner && (
            <div className="space-y-4">
              <h2 className="text-lg text-blue-300">House Edge</h2>
              <div className="bg-white/5 border border-blue-400/20 rounded-xl p-4 space-y-4">
                <div>
                  <Label className="text-white">Default House Edge: {defaultHouseEdge}%</Label>
                  <p className="text-xs text-blue-200/70 mt-1">
                    Sets the profit margin for all new bets in your book. Minimum 3%, Maximum 10%.
                  </p>
                </div>
                
                <Slider
                  value={[defaultHouseEdge]}
                  onValueChange={(value) => setDefaultHouseEdge(Math.max(3, Math.min(10, value[0])))}
                  min={3}
                  max={10}
                  step={1}
                  className="w-full"
                />

                <div className="flex justify-between text-xs text-blue-200/50">
                  <span>3% Min</span>
                  <span>7% Default</span>
                  <span>10% Max</span>
                </div>

                <div className="bg-green-500/10 border border-green-400/30 rounded-lg p-3">
                  <div className="text-xs text-green-300/70 mb-1">
                    Estimated profit per 1,000 chips wagered:
                  </div>
                  <div className="text-white">
                    +{Math.round(1000 * (defaultHouseEdge / 100))} chips
                  </div>
                </div>

                <div className="bg-blue-500/10 border border-blue-400/20 rounded-lg p-3">
                  <p className="text-xs text-blue-200/70">
                    💡 House edge is built into odds but never shown to players. This ensures your book stays profitable over time.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Features */}
          <div className="space-y-4">
            <h2 className="text-lg text-blue-300">Features</h2>
            
            <div className="flex items-center justify-between p-4 bg-white/5 rounded-xl border border-blue-400/20">
              <div>
                <p className="text-sm mb-1">Enable Leaderboard</p>
                <p className="text-xs text-blue-300/60">Show top bettors ranking</p>
              </div>
              <Switch
                checked={enableLeaderboard}
                onCheckedChange={setEnableLeaderboard}
              />
            </div>

            <div className="flex items-center justify-between p-4 bg-white/5 rounded-xl border border-blue-400/20">
              <div>
                <p className="text-sm mb-1">Connect to Union</p>
                <p className="text-xs text-blue-300/60">Join a network of books</p>
              </div>
              <Switch
                checked={enableUnion}
                onCheckedChange={setEnableUnion}
              />
            </div>
          </div>

          {/* Danger Zone - Owner Only */}
          {isOwner && (
            <div className="space-y-4 pt-4">
              <div className="bg-red-500/10 border border-red-400/30 rounded-xl p-4">
                <h2 className="text-lg text-red-400 mb-2">⚠️ Danger Zone</h2>
                <p className="text-sm text-red-300/70 mb-4">
                  Deleting a book is permanent and cannot be undone.
                </p>
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button
                      variant="outline"
                      className="w-full border-red-400/50 text-red-400 hover:bg-red-500/20 hover:border-red-400/70 justify-start"
                    >
                      <Trash2 className="h-4 w-4 mr-2" />
                      Delete Book
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent className="border-red-400/20 text-white max-w-md" style={{
                    background: 'linear-gradient(to bottom, #0C1B35 0%, #05122B 100%)'
                  }}>
                    <AlertDialogHeader>
                      <AlertDialogTitle className="text-red-400">Delete Book?</AlertDialogTitle>
                      <AlertDialogDescription className="text-blue-200/70">
                        Are you sure you want to delete <span className="text-white font-semibold">{book.name}</span>? 
                        This action cannot be undone. All bets, members, and data associated with this book will be permanently deleted.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel className="bg-white/5 border-blue-400/30 text-white hover:bg-white/10">
                        Cancel
                      </AlertDialogCancel>
                      <AlertDialogAction
                        onClick={onDeleteBook}
                        className="bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white border-0"
                      >
                        Delete Book
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </div>
            </div>
          )}
        </div>
      </ScrollArea>
    </div>
  );
}