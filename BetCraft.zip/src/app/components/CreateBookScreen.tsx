import { Label } from './ui/label';
import { ArrowLeft, Upload, Check } from 'lucide-react';
import { toast } from 'sonner';

interface CreateBookScreenProps {
  onNavigateBack: () => void;
  onCreateBook: (bookData: {
    name: string;
    logo: string;
  }) => void;
}

// Generate a random book code
const generateBookCode = () => {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let code = 'BC';
  for (let i = 0; i < 4; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return code;
};

const defaultEmojis = ['🏀', '🎬', '💻', '🎮', '⚽', '🎯', '🎲', '🏈', '⚾', '🎾', '🏐', '🎱', '🎳', '🥊', '🏆'];

export default function CreateBookScreen({ onNavigateBack, onCreateBook }: CreateBookScreenProps) {
  const [bookName, setBookName] = useState('');
  const [bookCode] = useState(generateBookCode());
  const [selectedLogo, setSelectedLogo] = useState('🏀');
  const [step, setStep] = useState<'create' | 'success'>('create');

  const handleCreate = () => {
    if (!bookName.trim()) {
      toast.error('Please enter a book name');
      return;
    }

    onCreateBook({
      name: bookName.trim(),
      logo: selectedLogo,
    });

    setStep('success');
  };

  if (step === 'success') {
    return (
      <div className="min-h-screen flex flex-col text-white" style={{
        background: 'linear-gradient(to bottom, #05122B 0%, #0C1B35 100%)'
      }}>
        <div className="flex-1 flex items-center justify-center p-6">
          <div className="text-center max-w-md">
            {/* Success Icon */}
            <div className="relative inline-block mb-6">
              <div className="absolute inset-0 bg-blue-500/30 blur-2xl rounded-full"></div>
              <div className="relative w-24 h-24 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center shadow-xl shadow-blue-500/50">
                <Check className="h-12 w-12 text-white" />
              </div>
            </div>

            <h1 className="text-3xl mb-3">Book Created!</h1>
            <p className="text-blue-200/70 mb-8">
              Your book <span className="text-blue-400">{bookName}</span> is ready to go.
              Share your book code with friends to let them join.
            </p>

            {/* Book Code Display */}
            <div className="bg-white/5 border border-blue-400/30 rounded-xl p-6 mb-8 backdrop-blur-sm">
              <p className="text-sm text-blue-300/70 mb-2">Your Book Code</p>
              <div className="text-4xl tracking-wider mb-2" style={{
                background: 'linear-gradient(135deg, #1A73E8 0%, #8B5CF6 100%)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                fontWeight: 'bold'
              }}>
                #{bookCode}
              </div>
              <p className="text-xs text-blue-200/50">Anyone can search this code to join</p>
            </div>

            <Button
              onClick={onNavigateBack}
              className="w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white border-0 shadow-lg shadow-blue-500/30 h-12"
            >
              Go to My Books
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col text-white" style={{
      background: 'linear-gradient(to bottom, #05122B 0%, #0C1B35 100%)'
    }}>
      {/* Header */}
      <div className="sticky top-0 z-30 backdrop-blur-lg border-b border-white/10" style={{
        background: 'rgba(5, 18, 43, 0.8)'
      }}>
        <div className="p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="icon"
              onClick={onNavigateBack}
              className="text-white hover:bg-white/10 rounded-full h-9 w-9"
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <h1 className="text-xl">Create Your Book</h1>
          </div>
          <div className="text-2xl tracking-tighter" style={{
            background: 'linear-gradient(135deg, #1A73E8 0%, #8B5CF6 100%)',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            fontWeight: 800
          }}>
            BC
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 p-6 overflow-y-auto">
        <div className="max-w-md mx-auto space-y-6">
          {/* Book Name Input */}
          <div className="space-y-2">
            <Label htmlFor="bookName" className="text-blue-200">Book Name</Label>
            <Input
              id="bookName"
              type="text"
              placeholder="e.g., Nick's Picks"
              value={bookName}
              onChange={(e) => setBookName(e.target.value)}
              className="bg-white/5 border-blue-400/30 text-white placeholder:text-blue-200/40 focus:bg-white/10 focus:border-blue-400/60 h-12 rounded-xl"
              maxLength={30}
            />
            <p className="text-xs text-blue-300/50">{bookName.length}/30 characters</p>
          </div>

          {/* Auto-Generated Code */}
          <div className="space-y-2">
            <Label className="text-blue-200">Book Code</Label>
            <div className="bg-white/5 border border-blue-400/30 rounded-xl p-4 backdrop-blur-sm">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-2xl tracking-wider" style={{
                    background: 'linear-gradient(135deg, #1A73E8 0%, #8B5CF6 100%)',
                    WebkitBackgroundClip: 'text',
                    WebkitTextFillColor: 'transparent',
                    fontWeight: 'bold'
                  }}>
                    #{bookCode}
                  </p>
                  <p className="text-xs text-blue-200/50 mt-1">Auto-generated • Searchable by others</p>
                </div>
                <div className="w-12 h-12 bg-gradient-to-br from-blue-500/20 to-purple-500/20 rounded-lg flex items-center justify-center border border-blue-400/30">
                  <span className="text-2xl">{selectedLogo}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Profile Image / Logo Selection */}
          <div className="space-y-2">
            <Label className="text-blue-200">Book Logo</Label>
            <p className="text-xs text-blue-300/50 mb-3">Choose an emoji to represent your book</p>
            <div className="grid grid-cols-5 gap-2">
              {defaultEmojis.map((emoji) => (
                <button
                  key={emoji}
                  onClick={() => setSelectedLogo(emoji)}
                  className={`aspect-square rounded-xl flex items-center justify-center text-3xl transition-all ${
                    selectedLogo === emoji
                      ? 'bg-gradient-to-br from-blue-500 to-purple-600 shadow-lg shadow-blue-500/30 scale-110'
                      : 'bg-white/5 hover:bg-white/10 border border-blue-400/20'
                  }`}
                >
                  {emoji}
                </button>
              ))}
            </div>
          </div>

          {/* Info Box */}
          <div className="bg-blue-500/10 border border-blue-400/30 rounded-xl p-4 backdrop-blur-sm">
            <p className="text-sm text-blue-300 mb-2">📘 What's Next?</p>
            <ul className="text-xs text-blue-200/70 space-y-1">
              <li>• Share your book code with friends</li>
              <li>• Customize settings and add a banner</li>
              <li>• Distribute chips to members</li>
              <li>• Create your first bet</li>
            </ul>
          </div>
        </div>
      </div>

      {/* Bottom CTA */}
      <div className="sticky bottom-0 p-6 border-t border-white/10 backdrop-blur-lg" style={{
        background: 'rgba(5, 18, 43, 0.9)'
      }}>
        <Button
          onClick={handleCreate}
          disabled={!bookName.trim()}
          className="w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white border-0 shadow-lg shadow-blue-500/30 h-12 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          Create Book
        </Button>
      </div>
    </div>
  );
}