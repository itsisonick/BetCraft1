import { ArrowLeft, MessageCircle, Trophy, Users, Coins, Mail, UsersRound, BarChart3, Settings, Hash, Bell } from 'lucide-react';
import { Badge } from './ui/badge';
import { toast } from 'sonner';

interface ClubPageProps {
  book: Book;
  bets: Bet[];
  players: Player[];
  user: User;
  userRole: 'Manager' | 'Agent' | 'Player';
  onNavigateBack: () => void;
  onNavigateToBetDetails: (betId: number) => void;
  onNavigateToCreateBet: () => void;
  onNavigateToBookSettings: () => void;
  onNavigateToClubData?: () => void;
  onSendChips: (bookId: number, playerId: number, amount: number) => boolean;
  onClaimChips: (bookId: number, playerId: number, amount: number) => boolean;
}

type BetFilter = 'All' | 'Sports' | 'IRL' | 'Funny' | 'Custom';
type ControlTab = 'Inbox' | 'Members' | 'Counter' | 'Data' | 'Admin';

export default function ClubPage({
  book,
  bets,
  players,
  user,
  userRole,
  onNavigateBack,
  onNavigateToBetDetails,
  onNavigateToCreateBet,
  onNavigateToBookSettings,
  onNavigateToClubData,
  onSendChips,
  onClaimChips,
}: ClubPageProps) {
  const isOwner = book.ownerId === user.id;
  const [activeFilter, setActiveFilter] = useState<BetFilter>('All');
  const [activeTab, setActiveTab] = useState<ControlTab | null>(null);
  const [selectedPlayer, setSelectedPlayer] = useState<Player | null>(null);
  const [chipAmount, setChipAmount] = useState<string>('');

  const filteredBets = activeFilter === 'All'
    ? bets
    : bets.filter(bet => bet.type === activeFilter);

  const handleSendChips = () => {
    if (!selectedPlayer) return;
    const amount = parseInt(chipAmount);
    if (isNaN(amount) || amount <= 0) {
      toast.error('Please enter a valid amount');
      return;
    }
    
    const success = onSendChips(book.id, selectedPlayer.id, amount);
    if (success) {
      toast.success(`Sent ${amount} chips to ${selectedPlayer.username}`);
      setSelectedPlayer(null);
      setChipAmount('');
    } else {
      toast.error('Insufficient blue chips in book');
    }
  };

  const handleClaimChips = () => {
    if (!selectedPlayer) return;
    const amount = parseInt(chipAmount);
    if (isNaN(amount) || amount <= 0) {
      toast.error('Please enter a valid amount');
      return;
    }
    
    const success = onClaimChips(book.id, selectedPlayer.id, amount);
    if (success) {
      toast.success(`Claimed ${amount} chips from ${selectedPlayer.username}`);
      setSelectedPlayer(null);
      setChipAmount('');
    } else {
      toast.error('Player does not have enough chips');
    }
  };

  return (
    <div className="min-h-screen flex flex-col text-white" style={{
      background: 'linear-gradient(to bottom, #05122B 0%, #0C1B35 100%)'
    }}>
      {/* Header - Top Navigation Bar */}
      <div className="sticky top-0 z-30 backdrop-blur-lg border-b border-white/10" style={{
        background: 'rgba(5, 18, 43, 0.8)'
      }}>
        <div className="p-4">
          <div className="flex items-center justify-between">
            {/* Left: BC Logo and Back Button */}
            <div className="flex items-center gap-3">
              <Button
                variant="ghost"
                size="icon"
                onClick={onNavigateBack}
                className="text-white hover:bg-white/10 rounded-full h-9 w-9"
              >
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <div className="text-2xl tracking-tighter" style={{
                background: 'linear-gradient(135deg, #1A73E8 0%, #8B5CF6 100%)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                fontWeight: 800
              }}>
                BC
              </div>
            </div>

            {/* Center: Category Tabs */}
            <div className="hidden md:flex gap-1">
              {(['All', 'Sports', 'IRL', 'Funny', 'Custom'] as BetFilter[]).map((filter) => (
                <button
                  key={filter}
                  onClick={() => setActiveFilter(filter)}
                  className={`px-4 py-1.5 text-sm transition-all relative ${
                    activeFilter === filter 
                      ? 'text-white' 
                      : 'text-white/50 hover:text-white/80'
                  }`}
                >
                  {filter}
                  {activeFilter === filter && (
                    <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-transparent via-blue-400 to-transparent shadow-lg shadow-blue-500/50"></div>
                  )}
                </button>
              ))}
            </div>

            {/* Right: Chip Balance, Bell, Profile */}
            <div className="flex items-center gap-2">
              {/* Owner - Show infinite blue chips */}
              {user.role === 'owner' && (
                <div className="hidden sm:flex items-center gap-1.5 bg-blue-500/10 rounded-lg px-3 py-1.5 border shadow-sm" style={{ borderColor: 'rgba(58, 128, 249, 0.3)', boxShadow: '0 2px 8px rgba(58, 128, 249, 0.2)' }}>
                  <span className="text-lg">🔵</span>
                  <span className="text-sm" style={{ color: '#3A80F9' }}>∞</span>
                </div>
              )}
              
              {/* Agent - Show both chip types */}
              {user.role === 'agent' && (
                <div className="hidden sm:flex items-center gap-2">
                  <div className="flex items-center gap-1.5 bg-blue-500/10 rounded-lg px-3 py-1.5 border" style={{ borderColor: 'rgba(58, 128, 249, 0.3)' }}>
                    <span className="text-sm">🔵</span>
                    <span className="text-sm" style={{ color: '#3A80F9' }}>{user.blueChips.toLocaleString()}</span>
                  </div>
                  <div className="flex items-center gap-1.5 bg-red-500/10 rounded-lg px-3 py-1.5 border" style={{ borderColor: 'rgba(242, 76, 76, 0.3)' }}>
                    <span className="text-sm">🔴</span>
                    <span className="text-sm" style={{ color: '#F24C4C' }}>{user.redChips.toLocaleString()}</span>
                  </div>
                </div>
              )}
              
              {/* Player - Show only red chips */}
              {user.role === 'player' && (
                <div className="hidden sm:flex items-center gap-1.5 bg-red-500/10 rounded-lg px-3 py-1.5 border shadow-sm" style={{ borderColor: 'rgba(242, 76, 76, 0.3)', boxShadow: '0 2px 8px rgba(242, 76, 76, 0.2)' }}>
                  <span className="text-sm">🔴</span>
                  <span className="text-sm" style={{ color: '#F24C4C' }}>{user.redChips.toLocaleString()}</span>
                </div>
              )}
              <Button
                variant="ghost"
                size="icon"
                className="text-white hover:bg-white/10 rounded-full h-9 w-9 relative"
              >
                <Bell className="h-4 w-4" />
                <div className="absolute top-1.5 right-1.5 w-2 h-2 bg-blue-400 rounded-full shadow-lg shadow-blue-400/50"></div>
              </Button>
              <Avatar className="h-8 w-8 border border-blue-400/30">
                <AvatarImage src={user.avatar} />
                <AvatarFallback className="bg-blue-600 text-xs">{user.username[0]}</AvatarFallback>
              </Avatar>
            </div>
          </div>
        </div>

        {/* Mobile Category Tabs */}
        <div className="md:hidden px-4 pb-3">
          <div className="flex gap-2 overflow-x-auto pb-1">
            {(['All', 'Sports', 'IRL', 'Funny', 'Custom'] as BetFilter[]).map((filter) => (
              <button
                key={filter}
                onClick={() => setActiveFilter(filter)}
                className={`px-4 py-1.5 text-sm rounded-full whitespace-nowrap transition-all ${
                  activeFilter === filter 
                    ? 'bg-blue-500 text-white shadow-lg shadow-blue-500/30' 
                    : 'bg-white/5 text-white/50 hover:text-white/80'
                }`}
              >
                {filter}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Book Info Section */}
      <div className="p-5">
        <div className="flex items-center gap-3 mb-4">
          {/* Square Logo Container with Neon Glow */}
          <div className="relative">
            <div className="absolute inset-0 bg-blue-500/30 blur-xl rounded-xl"></div>
            <div className="relative w-14 h-14 bg-gradient-to-br from-blue-500/20 to-purple-500/20 backdrop-blur-sm rounded-xl flex items-center justify-center border border-blue-400/30 shadow-lg shadow-blue-500/20">
              <div className="text-3xl">{book.logo}</div>
            </div>
          </div>
          
          <div className="flex-1 min-w-0">
            <h1 className="text-xl mb-1">{book.name}</h1>
            <div className="flex items-center gap-3 text-xs text-blue-300/70">
              <div className="flex items-center gap-1">
                <Hash className="h-3 w-3" />
                <span>{book.bookId}</span>
              </div>
              <div className="flex items-center gap-1">
                <Users className="h-3 w-3" />
                <span>{book.members} members</span>
              </div>
            </div>
          </div>
        </div>

        {/* Message Bar */}
        <div className="bg-blue-500/10 border border-blue-400/30 rounded-lg p-3 mb-4 backdrop-blur-sm">
          <p className="text-sm text-blue-200">
            💬 Message <span className="text-blue-400">@{book.ownerName}</span> for chips
          </p>
        </div>

        {/* Create Bet Button (Owner only) */}
        {isOwner && (
          <Button
            onClick={onNavigateToCreateBet}
            className="w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white border-0 shadow-lg shadow-blue-500/30 h-11 hover:shadow-blue-500/50 transition-all"
          >
            + Create New Bet
          </Button>
        )}
      </div>

      {/* Active Bets Section */}
      <div className="flex-1 px-5 pb-20">
        <div className="mb-4">
          <h2 className="text-lg mb-0.5">Active Bets</h2>
          <p className="text-xs text-blue-300/50">{filteredBets.length} available</p>
        </div>

        <ScrollArea className="h-[calc(100vh-420px)]">
          <div className="space-y-3 pr-2 pb-4">
            {filteredBets.map((bet) => (
              <BetCard
                key={bet.id}
                bet={bet}
                onViewDetails={() => onNavigateToBetDetails(bet.id)}
              />
            ))}
          </div>
        </ScrollArea>

        {filteredBets.length === 0 && (
          <div className="text-center py-16 opacity-50">
            <div className="text-5xl mb-3">🎲</div>
            <p className="text-blue-200/70">No {activeFilter !== 'All' ? activeFilter.toLowerCase() : ''} bets available</p>
          </div>
        )}
      </div>

      {/* Bottom Navigation - Translucent Navy */}
      <div className="fixed bottom-0 left-0 right-0 backdrop-blur-xl border-t border-white/10 shadow-2xl z-20" style={{
        background: 'rgba(5, 18, 43, 0.9)'
      }}>
        <div className="grid grid-cols-5 h-16">
          <button
            onClick={() => setActiveTab(activeTab === 'Inbox' ? null : 'Inbox')}
            className={`flex flex-col items-center justify-center gap-1 transition-all relative ${
              activeTab === 'Inbox' ? 'text-blue-400' : 'text-white/50 hover:text-white/80'
            }`}
          >
            {activeTab === 'Inbox' && (
              <div className="absolute top-0 left-1/2 transform -translate-x-1/2 w-12 h-0.5 bg-blue-400 shadow-lg shadow-blue-400/50"></div>
            )}
            <Mail className={`h-5 w-5 ${activeTab === 'Inbox' ? 'drop-shadow-[0_0_8px_rgba(26,115,232,0.6)]' : ''}`} />
            <span className="text-xs">Inbox</span>
          </button>
          
          <button
            onClick={() => setActiveTab(activeTab === 'Members' ? null : 'Members')}
            className={`flex flex-col items-center justify-center gap-1 transition-all relative ${
              activeTab === 'Members' ? 'text-blue-400' : 'text-white/50 hover:text-white/80'
            }`}
          >
            {activeTab === 'Members' && (
              <div className="absolute top-0 left-1/2 transform -translate-x-1/2 w-12 h-0.5 bg-blue-400 shadow-lg shadow-blue-400/50"></div>
            )}
            <Users className={`h-5 w-5 ${activeTab === 'Members' ? 'drop-shadow-[0_0_8px_rgba(26,115,232,0.6)]' : ''}`} />
            <span className="text-xs">Members</span>
          </button>
          
          <button
            onClick={() => setActiveTab(activeTab === 'Counter' ? null : 'Counter')}
            className={`flex flex-col items-center justify-center gap-1 transition-all relative ${
              activeTab === 'Counter' ? 'text-blue-400' : 'text-white/50 hover:text-white/80'
            }`}
          >
            {activeTab === 'Counter' && (
              <div className="absolute top-0 left-1/2 transform -translate-x-1/2 w-12 h-0.5 bg-blue-400 shadow-lg shadow-blue-400/50"></div>
            )}
            <Coins className={`h-5 w-5 ${activeTab === 'Counter' ? 'drop-shadow-[0_0_8px_rgba(26,115,232,0.6)]' : ''}`} />
            <span className="text-xs">Counter</span>
          </button>
          
          <button
            onClick={onNavigateToClubData}
            className="flex flex-col items-center justify-center gap-1 transition-all relative text-white/50 hover:text-white/80"
          >
            <BarChart3 className="h-5 w-5" />
            <span className="text-xs">Data</span>
          </button>
          
          <button
            onClick={() => setActiveTab(activeTab === 'Admin' ? null : 'Admin')}
            disabled={!isOwner}
            className={`flex flex-col items-center justify-center gap-1 transition-all relative ${
              !isOwner ? 'opacity-40 cursor-not-allowed' : 
              activeTab === 'Admin' ? 'text-blue-400' : 'text-white/50 hover:text-white/80'
            }`}
          >
            {activeTab === 'Admin' && (
              <div className="absolute top-0 left-1/2 transform -translate-x-1/2 w-12 h-0.5 bg-blue-400 shadow-lg shadow-blue-400/50"></div>
            )}
            <Settings className={`h-5 w-5 ${activeTab === 'Admin' ? 'drop-shadow-[0_0_8px_rgba(26,115,232,0.6)]' : ''}`} />
            <span className="text-xs">Admin</span>
          </button>
        </div>
      </div>

      {/* Control Panel Overlay */}
      {activeTab && (
        <div 
          className="fixed inset-0 bg-black/60 z-40"
          onClick={() => setActiveTab(null)}
        >
          <div 
            className="absolute bottom-16 left-0 right-0 border-t border-white/10 max-h-96 overflow-y-auto"
            style={{
              background: 'linear-gradient(to bottom, #0C1B35 0%, #05122B 100%)'
            }}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg">{activeTab}</h3>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setActiveTab(null)}
                  className="text-white hover:bg-white/10"
                >
                  Close
                </Button>
              </div>
              
              {activeTab === 'Inbox' && (
                <div className="text-white/60 text-sm">
                  <p>📬 No new messages</p>
                  <p className="mt-2">Book notifications and messages will appear here.</p>
                </div>
              )}
              
              {activeTab === 'Members' && (
                <div className="space-y-2">
                  {/* Chip Context Notice */}
                  <div className="bg-blue-500/10 border border-blue-400/20 rounded-lg p-3 mb-3">
                    <p className="text-xs text-blue-200/80">
                      💡 Chip balances shown are specific to <span className="text-blue-400">{book.name}</span> only.
                    </p>
                  </div>
                  
                  <div className="flex items-center justify-between p-3 bg-white/5 rounded-lg border border-blue-400/10">
                    <div>
                      <p className="text-sm">{book.ownerName} (Owner)</p>
                      <p className="text-xs" style={{ color: '#3A80F9' }}>🔵 ∞ chips</p>
                    </div>
                    <Badge className="bg-blue-500/20 text-blue-400 border-blue-400/30">Owner</Badge>
                  </div>
                  <div className="text-white/60 text-sm p-3">
                    + {book.members - 1} more members
                  </div>
                </div>
              )}
              
              {activeTab === 'Counter' && (
                <div className="space-y-4">
                  {/* Chip Context Notice */}
                  <div className="bg-blue-500/10 border border-blue-400/20 rounded-lg p-3 mb-3">
                    <p className="text-xs text-blue-200/80">
                      💡 Chip balances shown are specific to <span className="text-blue-400">{book.name}</span> only.
                    </p>
                  </div>

                  {/* Book Chip Totals */}
                  <div className="grid grid-cols-2 gap-3 mb-4">
                    <div className="bg-gradient-to-r from-red-500/10 to-rose-500/10 border rounded-lg p-3" style={{ borderColor: 'rgba(242, 76, 76, 0.3)' }}>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-sm">🔴</span>
                        <p className="text-xs text-red-400/70">Red Chips</p>
                      </div>
                      <p className="text-xl" style={{ color: '#F24C4C' }}>{book.totalRedChips.toLocaleString()}</p>
                      <p className="text-xs text-white/40 mt-1">Circulating in Book</p>
                    </div>
                    <div className="bg-gradient-to-r from-blue-500/10 to-cyan-500/10 border rounded-lg p-3" style={{ borderColor: 'rgba(58, 128, 249, 0.3)' }}>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-sm">🔵</span>
                        <p className="text-xs text-blue-400/70">Blue Chips</p>
                      </div>
                      <p className="text-xl" style={{ color: '#3A80F9' }}>{book.totalBlueChips.toLocaleString()}</p>
                      <p className="text-xs text-white/40 mt-1">Available to Distribute</p>
                    </div>
                  </div>

                  {/* Players List */}
                  <div>
                    <h4 className="text-sm text-white/70 mb-3">Players ({players.length})</h4>
                    <ScrollArea className="h-64">
                      <div className="space-y-2 pr-2">
                        {players.map((player) => (
                          <button
                            key={player.id}
                            onClick={() => setSelectedPlayer(player)}
                            className="w-full flex items-center justify-between p-3 bg-white/5 hover:bg-white/10 rounded-lg transition-colors border border-blue-400/10 hover:border-blue-400/30"
                          >
                            <div className="flex items-center gap-3">
                              <Avatar className="h-8 w-8">
                                <AvatarImage src={player.avatar} />
                                <AvatarFallback>{player.username[0]}</AvatarFallback>
                              </Avatar>
                              <div className="text-left">
                                <p className="text-sm">{player.username}</p>
                                <p className="text-xs text-blue-300/50">ID: {player.id}</p>
                              </div>
                            </div>
                            <div className="text-right">
                              <p className="text-sm text-red-400">{player.redChips.toLocaleString()}</p>
                              <p className="text-xs text-white/40">chips</p>
                            </div>
                          </button>
                        ))}
                      </div>
                    </ScrollArea>
                  </div>
                </div>
              )}
              
              {activeTab === 'Data' && (
                <div className="space-y-3">
                  <div className="grid grid-cols-2 gap-3">
                    <div className="bg-white/5 rounded-lg p-3 border border-blue-400/10">
                      <p className="text-xs text-blue-300/70 mb-1">Active Bets</p>
                      <p className="text-2xl">{book.activeBets}</p>
                    </div>
                    <div className="bg-white/5 rounded-lg p-3 border border-blue-400/10">
                      <p className="text-xs text-blue-300/70 mb-1">Total Volume</p>
                      <p className="text-2xl">{(book.totalRedChips * 2.5).toLocaleString()}</p>
                    </div>
                  </div>
                  <div className="bg-white/5 rounded-lg p-3 border border-blue-400/10">
                    <p className="text-xs text-blue-300/70 mb-2">Top Bettors</p>
                    <div className="space-y-1 text-sm">
                      <div className="flex justify-between">
                        <span>1. {book.ownerName}</span>
                        <span className="text-blue-400">12,500</span>
                      </div>
                      <div className="flex justify-between text-white/60">
                        <span>2. BetKing88</span>
                        <span>8,300</span>
                      </div>
                      <div className="flex justify-between text-white/60">
                        <span>3. LuckyChip</span>
                        <span>6,750</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}
              
              {activeTab === 'Admin' && isOwner && (
                <div className="space-y-3">
                  <div className="bg-blue-500/10 border border-blue-400/30 rounded-lg p-3 mb-3">
                    <p className="text-xs text-blue-300 mb-1">💡 Admin Features</p>
                    <p className="text-xs text-white/60">
                      Use blue chips to distribute red chips to players. Red chips can be claimed back.
                    </p>
                  </div>
                  <Button className="w-full bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 justify-start border-0 shadow-lg shadow-blue-500/20">
                    📊 Manage Bets
                  </Button>
                  <Button className="w-full bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700 justify-start border-0 shadow-lg shadow-purple-500/20">
                    <Coins className="h-4 w-4 mr-2" />
                    Distribute Chips (Blue → Red)
                  </Button>
                  <Button className="w-full bg-gradient-to-r from-violet-500 to-violet-600 hover:from-violet-600 hover:to-violet-700 justify-start border-0 shadow-lg shadow-violet-500/20">
                    👥 Manage Members
                  </Button>
                  <Button className="w-full bg-gradient-to-r from-indigo-500 to-indigo-600 hover:from-indigo-600 hover:to-indigo-700 justify-start border-0 shadow-lg shadow-indigo-500/20">
                    💵 Process Claims (Red → Cash)
                  </Button>
                  <Button 
                    onClick={onNavigateToBookSettings}
                    variant="outline" 
                    className="w-full border-blue-400/30 text-blue-300 hover:bg-blue-500/10 justify-start"
                  >
                    ⚙️ Book Settings
                  </Button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Player Chip Management Dialog */}
      <Dialog open={!!selectedPlayer} onOpenChange={() => setSelectedPlayer(null)}>
        <DialogContent className="border-blue-400/20 text-white" style={{
          background: 'linear-gradient(to bottom, #0C1B35 0%, #05122B 100%)'
        }}>
          <DialogHeader>
            <DialogTitle>Manage Chips</DialogTitle>
            <DialogDescription className="text-blue-300/60">
              {selectedPlayer?.username} • {selectedPlayer?.redChips.toLocaleString()} red chips
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 mt-4">
            <div>
              <label className="text-sm text-blue-300/70 mb-2 block">Amount</label>
              <Input
                type="number"
                placeholder="Enter amount"
                value={chipAmount}
                onChange={(e) => setChipAmount(e.target.value)}
                className="bg-white/5 border-blue-400/20 text-white"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <Button
                onClick={handleSendChips}
                className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 border-0 shadow-lg shadow-blue-500/30"
                disabled={!chipAmount || userRole === 'Player'}
              >
                <Coins className="h-4 w-4 mr-2" />
                Send Chips
              </Button>
              <Button
                onClick={handleClaimChips}
                className="bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700 border-0 shadow-lg shadow-purple-500/30"
                disabled={!chipAmount || userRole === 'Player'}
              >
                <Coins className="h-4 w-4 mr-2" />
                Claim Chips
              </Button>
            </div>

            {userRole === 'Player' && (
              <p className="text-xs text-blue-400 text-center">
                Only Managers and Agents can manage chips
              </p>
            )}

            <div className="bg-blue-500/10 border border-blue-400/30 rounded-lg p-3">
              <p className="text-xs text-blue-300 mb-1">💡 How it works</p>
              <p className="text-xs text-blue-200/60">
                <strong>Send:</strong> Converts blue chips → red chips for player<br />
                <strong>Claim:</strong> Converts player's red chips → blue chips
              </p>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}