import { useState } from 'react';
import { ArrowLeft, Calendar as CalendarIcon } from 'lucide-react';
import { Button } from './ui/button';
import { ScrollArea } from './ui/scroll-area';
import { Badge } from './ui/badge';
import { Popover, PopoverContent, PopoverTrigger } from './ui/popover';
import { Calendar } from './ui/calendar';

interface ClubDataScreenProps {
  bookId: string;
  bookName: string;
  onNavigateBack: () => void;
}

interface BetStats {
  id: string;
  title: string;
  mode: 'Book' | 'Prediction';
  status: 'In Progress' | 'Closed' | 'Pending';
  totalPool: number;
  participants: number;
  creatorFee: number;
  profitLoss: number;
  closesAt: string;
}

export function ClubDataScreen({ bookId, bookName, onNavigateBack }: ClubDataScreenProps) {
  const [selectedRange, setSelectedRange] = useState<'1' | '7' | '14'>('1');
  const [dateFrom, setDateFrom] = useState<Date | undefined>(new Date());
  const [dateTo, setDateTo] = useState<Date | undefined>(new Date());
  
  // Mock data - in real app, this would come from backend
  const mockBets: BetStats[] = [
    {
      id: '1',
      title: 'Who wins tonight\'s game?',
      mode: 'Book',
      status: 'In Progress',
      totalPool: 1200,
      participants: 24,
      creatorFee: 5,
      profitLoss: 110.44,
      closesAt: '11:00 PM',
    },
    {
      id: '2',
      title: 'Will it rain tomorrow?',
      mode: 'Prediction',
      status: 'In Progress',
      totalPool: 850,
      participants: 18,
      creatorFee: 3,
      profitLoss: 45.20,
      closesAt: '9:00 AM',
    },
    {
      id: '3',
      title: 'Best player performance',
      mode: 'Book',
      status: 'Closed',
      totalPool: 2100,
      participants: 32,
      creatorFee: 7,
      profitLoss: 147.80,
      closesAt: 'Yesterday',
    },
    {
      id: '4',
      title: 'Season champion prediction',
      mode: 'Prediction',
      status: 'In Progress',
      totalPool: 670,
      participants: 12,
      creatorFee: 2,
      profitLoss: -43.27,
      closesAt: 'Dec 31',
    },
  ];

  // Calculate summary stats based on selected range
  const getSummaryStats = () => {
    const betsCreated = selectedRange === '1' ? 17 : selectedRange === '7' ? 48 : 92;
    const profitLoss = selectedRange === '1' ? 260.17 : selectedRange === '7' ? 1240.55 : 2890.32;
    const totalVolume = selectedRange === '1' ? 4820 : selectedRange === '7' ? 18200 : 35400;
    
    return { betsCreated, profitLoss, totalVolume };
  };

  const stats = getSummaryStats();
  
  // Detect timezone
  const timezone = `UTC${new Date().getTimezoneOffset() / -60 >= 0 ? '+' : ''}${new Date().getTimezoneOffset() / -60}`;

  const getStatusBadge = (status: BetStats['status']) => {
    switch (status) {
      case 'In Progress':
        return <Badge className="bg-green-500/20 text-green-300 border-green-400/30">🟢 In Progress</Badge>;
      case 'Closed':
        return <Badge className="bg-red-500/20 text-red-300 border-red-400/30">🔴 Closed</Badge>;
      case 'Pending':
        return <Badge className="bg-gray-500/20 text-gray-300 border-gray-400/30">⚫ Pending</Badge>;
    }
  };

  return (
    <div
      className="min-h-screen flex flex-col text-white"
      style={{
        background: 'linear-gradient(to bottom, #05122B 0%, #0C1B35 100%)',
      }}
    >
      {/* Header */}
      <div className="border-b border-blue-400/20 bg-gradient-to-r from-blue-600/10 to-purple-600/10 backdrop-blur-sm">
        <div className="p-4 flex items-center gap-3">
          <Button
            variant="ghost"
            size="icon"
            onClick={onNavigateBack}
            className="text-blue-300 hover:bg-white/5"
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div className="flex-1">
            <h1 className="text-xl text-white">Club Data</h1>
            <div className="text-xs text-blue-200/60">{bookName}</div>
          </div>
          <Popover>
            <PopoverTrigger className="inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md border border-blue-400/30 bg-transparent px-3 py-1.5 text-sm text-blue-300 transition-colors hover:bg-blue-500/10">
              <CalendarIcon className="h-4 w-4" />
              {dateFrom && dateTo && dateFrom.getTime() === dateTo.getTime()
                ? dateFrom.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
                : dateFrom && dateTo
                ? `${dateFrom.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })} - ${dateTo.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}`
                : 'Select Date'}
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0 bg-[#0C1B35] border-blue-400/30" align="end">
              <div className="p-3 space-y-3">
                <div className="text-xs text-blue-200/70">Select Date Range</div>
                <Calendar
                  mode="single"
                  selected={dateFrom}
                  onSelect={setDateFrom}
                  className="rounded-md"
                />
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    className="flex-1 border-blue-400/30 text-blue-300 hover:bg-blue-500/10"
                    onClick={() => {
                      const today = new Date();
                      setDateFrom(today);
                      setDateTo(today);
                      setSelectedRange('1');
                    }}
                  >
                    Today
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    className="flex-1 border-blue-400/30 text-blue-300 hover:bg-blue-500/10"
                    onClick={() => {
                      const today = new Date();
                      const weekAgo = new Date(today);
                      weekAgo.setDate(weekAgo.getDate() - 7);
                      setDateFrom(weekAgo);
                      setDateTo(today);
                      setSelectedRange('7');
                    }}
                  >
                    Last 7 Days
                  </Button>
                </div>
              </div>
            </PopoverContent>
          </Popover>
        </div>
        <div className="px-4 pb-3 text-xs text-blue-200/50">
          Time Zone: {timezone}
        </div>
      </div>

      {/* Tabs */}
      <div className="border-b border-blue-400/20 bg-white/5 px-4 pt-3">
        <div className="flex gap-2">
          <button
            onClick={() => setSelectedRange('1')}
            className={`px-4 py-2 rounded-t-lg transition-all ${
              selectedRange === '1'
                ? 'bg-blue-500/20 text-blue-300 border-t border-x border-blue-400/30'
                : 'text-blue-200/50 hover:text-blue-200/80 hover:bg-white/5'
            }`}
          >
            1 Day
          </button>
          <button
            onClick={() => setSelectedRange('7')}
            className={`px-4 py-2 rounded-t-lg transition-all ${
              selectedRange === '7'
                ? 'bg-blue-500/20 text-blue-300 border-t border-x border-blue-400/30'
                : 'text-blue-200/50 hover:text-blue-200/80 hover:bg-white/5'
            }`}
          >
            7 Days
          </button>
          <button
            onClick={() => setSelectedRange('14')}
            className={`px-4 py-2 rounded-t-lg transition-all ${
              selectedRange === '14'
                ? 'bg-blue-500/20 text-blue-300 border-t border-x border-blue-400/30'
                : 'text-blue-200/50 hover:text-blue-200/80 hover:bg-white/5'
            }`}
          >
            14 Days
          </button>
        </div>
      </div>

      <ScrollArea className="flex-1">
        <div className="p-4 space-y-4">
          {/* Summary Section */}
          <div className="bg-gradient-to-br from-blue-500/10 to-purple-500/10 border border-blue-400/30 rounded-xl p-4">
            <div className="grid grid-cols-3 gap-4">
              {/* Bets Created */}
              <div className="space-y-1">
                <div className="text-xs text-blue-200/60">Bets Created</div>
                <div className="text-2xl text-white">{stats.betsCreated}</div>
              </div>

              {/* Profit / Loss */}
              <div className="space-y-1">
                <div className="text-xs text-blue-200/60">Profit / Loss</div>
                <div
                  className={`text-2xl ${
                    stats.profitLoss >= 0 ? 'text-green-400' : 'text-red-400'
                  }`}
                >
                  {stats.profitLoss >= 0 ? '+' : ''}
                  {stats.profitLoss.toFixed(2)}
                </div>
                <div className="text-xs text-blue-200/50">chips</div>
              </div>

              {/* Total Volume */}
              <div className="space-y-1">
                <div className="text-xs text-blue-200/60">Total Volume</div>
                <div className="text-2xl text-white">
                  {stats.totalVolume.toLocaleString()}
                </div>
                <div className="text-xs text-blue-200/50">chips</div>
              </div>
            </div>
          </div>

          {/* Bet List */}
          <div className="space-y-3">
            <div className="text-sm text-blue-200/70 px-1">Active & Recent Bets</div>
            {mockBets.map((bet) => (
              <div
                key={bet.id}
                className="bg-gradient-to-br from-blue-500/5 to-purple-500/5 border border-blue-400/20 rounded-xl p-4 space-y-3 hover:border-blue-400/40 transition-all"
              >
                {/* Status & Title */}
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1 space-y-1">
                    {getStatusBadge(bet.status)}
                    <h3 className="text-white">{bet.title}</h3>
                  </div>
                </div>

                {/* Stats Grid */}
                <div className="grid grid-cols-2 gap-x-4 gap-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-blue-200/60">Mode:</span>
                    <span className="text-white">{bet.mode}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-blue-200/60">Total Pool:</span>
                    <span className="text-white">{bet.totalPool} chips</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-blue-200/60">Participants:</span>
                    <span className="text-white">{bet.participants}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-blue-200/60">Creator Fee:</span>
                    <span className="text-white">{bet.creatorFee}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-blue-200/60">Profit / Loss:</span>
                    <span
                      className={
                        bet.profitLoss >= 0 ? 'text-green-400' : 'text-red-400'
                      }
                    >
                      {bet.profitLoss >= 0 ? '+' : ''}
                      {bet.profitLoss.toFixed(2)}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-blue-200/60">Closes:</span>
                    <span className="text-white">{bet.closesAt}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Empty state if no bets */}
          {mockBets.length === 0 && (
            <div className="text-center py-12 space-y-2">
              <div className="text-4xl">📊</div>
              <div className="text-blue-200/60">No bet data for this period</div>
              <div className="text-xs text-blue-200/40">
                Create some bets to see analytics here
              </div>
            </div>
          )}
        </div>
      </ScrollArea>
    </div>
  );
}
