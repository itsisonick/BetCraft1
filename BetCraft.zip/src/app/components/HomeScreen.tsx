import { useState } from 'react';
import { User, Book, UserRole, Screen } from '../App';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Button } from './ui/button';
import { Input } from './ui/input';
import BookCard from './BookCard';
import { Search, Home, Dice1, TrendingUp, User as UserIcon, Plus } from 'lucide-react';

interface HomeScreenProps {
  user: User;
  books: Book[];
  userRoles: UserRole[];
  onNavigateToBook: (bookId: number) => void;
  onNavigateToProfile: () => void;
  onNavigateToScreen: (screen: Screen) => void;
  onNavigateToCreateBook: () => void;
}

export default function HomeScreen({
  user,
  books,
  userRoles,
  onNavigateToBook,
  onNavigateToProfile,
  onNavigateToScreen,
  onNavigateToCreateBook,
}: HomeScreenProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState<'home' | 'bets' | 'activity' | 'profile'>('home');
  const userBooks = books.filter((book) => user.booksJoined.includes(book.id));

  const getUserRole = (bookId: number) => {
    return userRoles.find(r => r.bookId === bookId)?.role || 'Player';
  };

  const handleTabClick = (tab: 'home' | 'bets' | 'activity' | 'profile') => {
    setActiveTab(tab);
    if (tab === 'profile') {
      onNavigateToProfile();
    } else if (tab === 'bets') {
      onNavigateToScreen('bets');
    } else if (tab === 'activity') {
      onNavigateToScreen('activity');
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-blue-900 via-purple-900 to-blue-950 text-white pb-20">
      {/* Profile Header Card */}
      <div className="p-6 pb-4">
        <div className="relative bg-gradient-to-br from-blue-500/20 via-purple-500/20 to-blue-500/20 backdrop-blur-sm rounded-2xl p-5 border border-blue-400/30 shadow-lg shadow-blue-500/20">
          {/* Neon glow effect */}
          <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-blue-500/10 to-purple-500/10 blur-xl"></div>
          
          <div className="relative flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Avatar className="h-14 w-14 border-2 border-blue-400 shadow-lg shadow-blue-500/50">
                <AvatarImage src={user.avatar} />
                <AvatarFallback className="bg-blue-600">{user.username[0]}</AvatarFallback>
              </Avatar>
              <div>
                <h2 className="text-lg">{user.username}</h2>
                <p className="text-sm text-blue-200">ID: {user.id}</p>
              </div>
            </div>
            <Button
              onClick={onNavigateToProfile}
              variant="outline"
              className="border-blue-400/50 text-blue-200 hover:bg-blue-500/20 hover:text-white text-sm h-9"
            >
              View Profile
            </Button>
          </div>

          {/* Stats and Membership */}
          <div className="relative mt-4 pt-4 border-t border-white/10">
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-gradient-to-br from-blue-500/20 to-cyan-500/20 rounded-lg p-3 border border-blue-400/30">
                <p className="text-xs text-blue-300 mb-1">Books Joined</p>
                <p className="text-2xl text-blue-400">{user.booksJoined.length}</p>
                <p className="text-xs text-white/40 mt-0.5">Active</p>
              </div>
              <Button
                className="bg-gradient-to-br from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700 border-0 h-auto rounded-lg shadow-lg shadow-purple-500/30 hover:shadow-purple-500/50 transition-all p-3"
                onClick={() => {/* TODO: Add upgrade membership functionality */}}
              >
                <div className="flex flex-col items-center justify-center w-full">
                  <p className="text-xs">Upgrade</p>
                  <p className="text-sm">Membership</p>
                </div>
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Search Bar */}
      <div className="px-6 pb-4">
        <div className="relative">
          <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 h-4 w-4 text-blue-300" />
          <Input
            type="text"
            placeholder="Search books by code..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-11 pr-4 bg-white/5 border border-blue-400/30 text-white placeholder:text-blue-200/50 focus:bg-white/10 focus:border-blue-400/60 h-12 rounded-xl shadow-lg shadow-blue-500/10"
          />
        </div>
      </div>

      {/* My Books Section */}
      <div className="flex-1">
        <div className="px-6 mb-4">
          <h2 className="text-2xl mb-1">My Books</h2>
          <p className="text-sm text-blue-200/70">Join bets with your friends</p>
        </div>

        {/* Create Your Own Book Button */}
        <div className="px-6 mb-4">
          <Button
            onClick={onNavigateToCreateBook}
            className="w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white border-0 shadow-lg shadow-blue-500/30 h-12 hover:shadow-blue-500/50 transition-all"
          >
            <Plus className="h-5 w-5 mr-2" />
            Create Your Own Book
          </Button>
        </div>

        {/* Horizontal Swipe Carousel for Book Cards */}
        {userBooks.length > 0 ? (
          <div 
            className="overflow-x-auto pb-4 scrollbar-hide"
            style={{
              scrollSnapType: 'x mandatory',
              scrollBehavior: 'smooth',
              WebkitOverflowScrolling: 'touch',
            }}
          >
            <div className="flex gap-4 px-6">
              {userBooks.map((book) => (
                <div
                  key={book.id}
                  className="flex-shrink-0"
                  style={{
                    width: 'calc(90vw - 48px)',
                    maxWidth: '420px',
                    minHeight: '220px',
                    scrollSnapAlign: 'start',
                  }}
                >
                  <BookCard 
                    book={book} 
                    role={getUserRole(book.id)}
                    onClick={() => onNavigateToBook(book.id)} 
                  />
                </div>
              ))}
            </div>
          </div>
        ) : (
          <div className="text-center py-12 opacity-60 px-6">
            <div className="text-5xl mb-3">📚</div>
            <p className="text-lg mb-2">No books yet</p>
            <p className="text-sm text-blue-200/70">Create your own or search for existing ones</p>
          </div>
        )}
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-gradient-to-r from-slate-900/95 via-slate-800/95 to-slate-900/95 backdrop-blur-lg border-t border-white/10 shadow-2xl">
        <div className="mx-auto max-w-md relative">
          <div className="grid grid-cols-4 h-16">
            <button
              onClick={() => handleTabClick('home')}
              className={`flex flex-col items-center justify-center gap-1 transition-all ${
                activeTab === 'home' 
                  ? 'text-blue-400' 
                  : 'text-white/50 hover:text-white/80'
              }`}
            >
              <Home className={`h-5 w-5 ${activeTab === 'home' ? 'fill-blue-400' : ''}`} />
              <span className="text-xs">Home</span>
            </button>
            
            <button
              onClick={() => handleTabClick('bets')}
              className={`flex flex-col items-center justify-center gap-1 transition-all ${
                activeTab === 'bets' 
                  ? 'text-blue-400' 
                  : 'text-white/50 hover:text-white/80'
              }`}
            >
              <Dice1 className="h-5 w-5" />
              <span className="text-xs">Bets</span>
            </button>
            
            <button
              onClick={() => handleTabClick('activity')}
              className={`flex flex-col items-center justify-center gap-1 transition-all ${
                activeTab === 'activity' 
                  ? 'text-blue-400' 
                  : 'text-white/50 hover:text-white/80'
              }`}
            >
              <TrendingUp className="h-5 w-5" />
              <span className="text-xs">Activity</span>
            </button>
            
            <button
              onClick={() => handleTabClick('profile')}
              className={`flex flex-col items-center justify-center gap-1 transition-all ${
                activeTab === 'profile' 
                  ? 'text-blue-400' 
                  : 'text-white/50 hover:text-white/80'
              }`}
            >
              <UserIcon className="h-5 w-5" />
              <span className="text-xs">Profile</span>
            </button>
          </div>

          {/* Floating + Button */}
          <button
            onClick={onNavigateToCreateBook}
            className="absolute -top-8 left-1/2 transform -translate-x-1/2 w-14 h-14 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full shadow-lg shadow-blue-500/50 flex items-center justify-center hover:scale-110 transition-transform border-4 border-slate-900"
          >
            <Plus className="h-6 w-6 text-white" />
          </button>
        </div>
      </div>
    </div>
  );
}
